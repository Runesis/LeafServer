# -*- coding:utf8 -*-

from twisted.enterprise import adbapi

from MySQLdb import _mysql

from bellisenv import *

from struct import *
import hashlib, thread
import re

class AccountElement(object):
    __slots__ = ('uid','sid','password','name','sex','avatarcount','birth','publicbirth','telephone','publictelephone','domaincode','address1','address2','email','profile','passwordquestion','passwordanswer','joindate')

class AvatarElement(object):
	__slots__ = ('uid','aid','aorder','character','nick','knights','gp','fp','bodyback','bodyfront','hair','hairacc','clothes','trousers','shoes','weapon','accessory1','accessory2','accessory3','accessory4','accessory5','accessory6','accessory7')

class AccountManager:
    __lockObj = thread.allocate_lock()
    __st = None

    def __new__(self, *args, **kwargs):
        return self.getInstance(self, *args, **kwargs)

    def __init__(self):
        self.db = adbapi.ConnectionPool("MySQLdb", user=BellisEnv.DB_USER, passwd=BellisEnv.DB_PASS, host=BellisEnv.DB_HOST, db=BellisEnv.DB_NAME, cp_reconnect=1)
        self.conn = self.db.connect()
        self.cursor = self.conn.cursor()

        self.cursor.execute("set names utf8");

    def getInstance(self, *args, **kwargs):
        self.__lockObj.acquire()
        try:
            if self.__st is None:
                self.__st = object.__new__(self, *args, **kwargs)
    
        finally:
            self.__lockObj.release()

        return self.__st

    def isExistsAvatarName(self, name):
        self.cursor.execute("SELECT count(*) FROM %s WHERE `nick` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, unicode(name,'euckr').encode('utf8')))
        result = self.cursor.fetchall()

        if (result[0])[0] != 0:
            return 1
        else:
            return 0

    def isValidAccountID(self, sid):
        return re.match("[^-a-zA-Z0-9/]",sid)

    def isExistsAccountID(self, sid):
        self.cursor.execute("SELECT count(*) FROM %s WHERE `sid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, sid))
        result = self.cursor.fetchall()

        if (result[0])[0] != 0:
            return 1
        else:
            return 0

    def signup(self, recvId, recvPass, recvName, recvGender):
        self.cursor.execute("INSERT INTO `%s` (`uid`,`sid`,`sex`,`password`,`name`) VALUES (NULL,'%s','%s',md5('%s'),'%s')" % (BellisEnv.TABLE_ACCOUNT_NAME, unicode(recvId,'euckr').encode('utf8'), recvGender, recvPass, unicode(recvName,'euckr').encode('utf8')))
        self.conn.commit()

    def createAvatar(self, uid, character, name):
        self.cursor.execute("UPDATE %s SET `avatarcount` = `avatarcount` + 1 WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        self.conn.commit()

        c = ord(character)

        if c == 0:
            bodyback = 2
            bodyfront = 22
            hair = 484
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 1:
            bodyback = 2
            bodyfront = 55
            hair = 485
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 2:
            bodyback = 2
            bodyfront = 88
            hair = 486
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 3:
            bodyback = 2
            bodyfront = 121
            hair = 487
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 4:
            bodyback = 2
            bodyfront = 187
            hair = 488
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 5:
            bodyback = 2
            bodyfront = 220
            hair = 489
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 6:
            bodyback = 2
            bodyfront = 2
            hair = 490
            clothes = 1004
            trousers = 1005
            shoes = 1006

        elif c == 128:
            bodyback = 3
            bodyfront = 253
            hair = 491
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 129:
            bodyback = 3
            bodyfront = 286
            hair = 492
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 130:
            bodyback = 3
            bodyfront = 319
            hair = 493
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 131:
            bodyback = 3
            bodyfront = 352
            hair = 494
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 132:
            bodyback = 3
            bodyfront = 385
            hair = 495
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 133:
            bodyback = 3
            bodyfront = 418
            hair = 496
            clothes = 1007
            trousers = 1008
            shoes = 1009

        elif c == 134:
            bodyback = 3
            bodyfront = 451
            hair = 497
            clothes = 1007
            trousers = 1008
            shoes = 1009

        else:
            print 'createAvatar() exception!'

        idxs = [bodyback, bodyfront, hair, clothes, trousers, shoes]
        gp = BellisEnv.GP_NEWBIE

        self.cursor.execute("SELECT avatarcount FROM %s WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        result = self.cursor.fetchall()
        acount = (result[0])[0]

        self.cursor.execute("INSERT INTO `%s` (`aid`,`uid`,`aorder`,`character`,`nick`,`bodyback`,`bodyfront`,`hair`,`clothes`,`trousers`,`shoes`,`lastlogin`, `gp`) VALUES (NULL,'%d', '%d', '%d','%s','%d','%d','%d','%d','%d','%d',now(), '%d')" % (BellisEnv.TABLE_AVATAR_NAME, int(uid), acount, c, unicode(name,'euckr').encode('utf8'), bodyback, bodyfront, hair, clothes, trousers, shoes, gp))
        self.conn.commit()

        aid = self.getAIDByAOrder(uid, acount-1)

        self.itemToInventory(idxs, 1, aid)

        return '\x00\x00\x00\x00' + chr(acount) + pack('1s22s5shhhhhhhhhhhhhhhh24s24sll12s',chr(int(c)),name,'\x00'*5,bodyback,bodyfront,hair,0,clothes,trousers,shoes,0,0,0,0,0,0,0,0,0,'\x00'*24,'\x20',gp,0,'\x00'*12)

    def itemToInventory(self, idxlist, itype, aid):
        for x in range(len(idxlist)):
            self.cursor.execute("INSERT INTO `%s` (`id`,`aid`,`itemidx`,`itemtype`,`gettime`) VALUES (NULL,'%s','%d','%d',now())" % (BellisEnv.TABLE_INVENTORY_NAME, aid, idxlist[x], itype))
        self.conn.commit()    

    def signupError(self, failure):
        failure.trap(StandardError)
        print failure

    def auth(self, recvId, recvPass):
        self.cursor.execute("SELECT uid FROM %s WHERE `sid` = '%s' AND `password` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, unicode(recvId,'euckr').encode('utf8'), (hashlib.md5(recvPass)).hexdigest()))

        print (hashlib.md5(recvPass)).hexdigest()

        result = self.cursor.fetchall()

        if (result == ()) == True:
            return 0
        else:
            return str((result[0])[0]) # 09. 06. 09

    def setOnline(self, uid):
        print '    * ACCOUNT *  UID #%s is now Online.' % (uid)
        self.db.runOperation("UPDATE %s SET `online` = '1' WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        self.conn.commit()

    def setOffline(self, uid):
        print '    * ACCOUNT *  UID #%s is now Offline.' % (uid)
        self.db.runOperation("UPDATE %s SET `online` = '0' WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        self.conn.commit()

    def getAIDByAOrder(self, uid, aorder):
        self.cursor.execute("SELECT aid FROM %s WHERE `uid` = '%s' and `aorder` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, uid, str(aorder+1)))
        result = self.cursor.fetchall()
        aid = (result[0])[0]
        return str(aid)
    
    def getAvatarCount(self, uid):
        self.cursor.execute("SELECT avatarcount FROM %s WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        result = self.cursor.fetchall()
        return (result[0])[0]

    def getAvatarNameByAOrder(self, uid, aorder):
        self.cursor.execute("SELECT nick FROM %s WHERE `uid` = '%s' and `aorder` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, uid, str(aorder+1)))
        result = self.cursor.fetchall()
        avatarname = (result[0])[0]
        return unicode(avatarname, 'utf-8').encode('euc-kr')

    def getUIDBySID(self, sid):
        self.cursor.execute("SELECT uid FROM %s WHERE `sid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, unicode(sid,'euckr').encode('utf8')))
        result = self.cursor.fetchall()
        uid = (result[0])[0]
        return str(uid)

    def initializeAvatarData(self):
        self.db.runOperation("UPDATE %s, %s SET `visitgp` = '0' WHERE dayofmonth(`%s`.`lastlogin`) < dayofmonth(now()) and `%s`.`sid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, BellisEnv.TABLE_AVATAR_NAME, BellisEnv.TABLE_AVATAR_NAME, BellisEnv.TABLE_ACCOUNT_NAME, BellisEnv.SERVER_ACCOUNT_ID))
        self.db.runOperation("UPDATE %s, %s SET `visitgp` = '0' WHERE dayofmonth(`%s`.`lastlogin`) = dayofmonth(`%s`.`lastlogin`) and hour(`%s`.`lastlogin`) < 7 and `%s`.`sid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, BellisEnv.TABLE_ACCOUNT_NAME, BellisEnv.TABLE_AVATAR_NAME, BellisEnv.TABLE_ACCOUNT_NAME, BellisEnv.TABLE_AVATAR_NAME, BellisEnv.TABLE_ACCOUNT_NAME, BellisEnv.SERVER_ACCOUNT_ID))
        self.conn.commit()

    def updateGPByAID(self, aid):
        self.db.runOperation("UPDATE %s SET `gp` = `gp` + %d WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, BellisEnv.GP_PER_HOUR, aid))
        self.conn.commit()

    def updateTotalTimeByAID(self, aid):
        self.db.runOperation("UPDATE %s SET `totaltime` = `totaltime` + 1 WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
        self.conn.commit()

    def updateLastLoginDate(self, aid):
        self.db.runOperation("UPDATE %s SET `lastlogin` = now() WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
        self.conn.commit()

    def updateVisitGP(self, aid):
        self.cursor.execute("SELECT visitgp FROM %s WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
        result = self.cursor.fetchall()[0]

        if int(result[0]) == 0:
            self.db.runOperation("UPDATE %s SET `gp` = `gp` + %d WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, BellisEnv.VISIT_GP, aid))
            self.db.runOperation("UPDATE %s SET `visitgp` = '1' WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
            self.conn.commit()

            return 0
        else:
            return 1

    def getAvatarData(self, aid):
        self.cursor.execute("SELECT * FROM %s WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
        result = self.cursor.fetchall()[0]

        avatard = pack('1s22s5shhhhhhhhhhhhhhhh24s24sll12s',chr(int(result[3])),unicode(result[4], 'utf-8').encode('euc-kr'),'\x00'*5,int(result[8]),int(result[9]),int(result[10]),int(result[11]),int(result[12]),int(result[13]),int(result[14]),int(result[15]),int(result[16]),int(result[17]),int(result[18]),int(result[19]),int(result[20]),int(result[21]),int(result[22]),int(result[23]),'\x00'*24,unicode(result[5], 'utf-8').encode('euc-kr'),int(result[6]),int(result[7]),'\x00'*12)
        
        self.cursor.execute("SELECT * FROM %s WHERE `aid` = '%s' ORDER BY `itemtype` AND `itemidx` ASC" % (BellisEnv.TABLE_INVENTORY_NAME, aid))
        result = self.cursor.fetchall()

        inventoryd = ''

        for record in range(len(result)):
            inventoryd = inventoryd + pack('hh', int(result[record][2]), int(result[record][3]))

        avatard = avatard + pack('140s', inventoryd)
        return avatard

    def getAccountDataForLogin(self, uid):
        print '    * ACCOUNT *  Retrieving data of account #%s' % (uid)

        avatard = ''

        self.cursor.execute("SELECT * FROM %s WHERE `uid` = '%s' ORDER BY `aorder` ASC" % (BellisEnv.TABLE_AVATAR_NAME, uid))
        result = self.cursor.fetchall()
        
        for record in range(len(result)):
            avatard = avatard + pack('1s22s5shhhhhhhhhhhhhhhh24s24sll12s',chr(int(result[record][3])),unicode(result[record][4], 'utf-8').encode('euc-kr'),'\x00'*5,int(result[record][8]),int(result[record][9]),int(result[record][10]),int(result[record][11]),int(result[record][12]),int(result[record][13]),int(result[record][14]),int(result[record][15]),int(result[record][16]),int(result[record][17]),int(result[record][18]),int(result[record][19]),int(result[record][20]),int(result[record][21]),int(result[record][22]),int(result[record][23]),'\x00'*24,unicode(result[record][5], 'utf-8').encode('euc-kr'),int(result[record][6]),int(result[record][7]),'\x00'*12)
        
        self.cursor.execute("SELECT * FROM %s WHERE `uid` = '%s'" % (BellisEnv.TABLE_ACCOUNT_NAME, uid))
        result = self.cursor.fetchall()[0]

        if result[4] == 'M':
            sex = 0
        elif result[4] == 'F':
            sex = 1
        else:
            print '    * ACCOUNT * Avatar gender parsing exception!!!'
            sex = 0

        tavatar = int(result[5])
        if tavatar == 0:
            tavatar = 1

        accountd = pack('l16s12shh121s384s511s5s', 0, result[1], unicode(result[3], 'utf-8').encode('euc-kr'), sex, tavatar, '\x00'*121, avatard, '\x00'*511, '\x00\x37\xcb\xce\x3f') 
        #accountd = pack('l16s12shhh119s384s511s5s', 0, result[1], unicode(result[3], 'utf-8').encode('euc-kr'), sex, int(result[5]), 3, '\x00'*119, avatard, '\x00'*511, '\x00\x37\xcb\xce\x3f') 
        return accountd

    def loadCardShopData(self, type):
        if type == '\x00':
            rtype = 'N'
        elif type == '\x01':
            rtype = 'V'
        else:
            print 'loadCardShopData() - get exception!'
            
        self.cursor.execute("SELECT * FROM %s WHERE `type` = '%s' and `quantity` > 0" % (BellisEnv.TABLE_CARD_SHOP, rtype))
        result = self.cursor.fetchall()
        return result

    def getCardInfo(self, idx):
        self.cursor.execute("SELECT * FROM %s WHERE `idx` = '%d'" % (BellisEnv.TABLE_CARD_SHOP, idx))
        result = self.cursor.fetchall()[0]
        return result

    def buyCardItem(self, aid, idx):
        selectedCard = self.getCardInfo(idx)
        resultgp = self.setAvatarStatus(aid, 'gp', (-1*selectedCard[2]))

        if resultgp == 'no':
            return 0
        else:          
            self.cursor.execute("UPDATE %s SET `quantity` = `quantity` - 1 WHERE `idx` = '%d'" % (BellisEnv.TABLE_CARD_SHOP, idx))
            self.conn.commit()          

            self.itemToInventory([idx], 3, aid)      

            if selectedCard[1] == 'N':
                cardtype = '\x00'
            elif selectedCard[2] == 'V':
                cardtype = '\x01'
            else:
                print 'buyCardItem() - get exception!'
                cardtype = '\x00'

            return [selectedCard[2], resultgp, cardtype]

    def setAvatarStatus(self, aid, stat, arg):
        if stat == 'gp':
            self.cursor.execute("SELECT gp FROM %s WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
            result = self.cursor.fetchall()[0]

            if (int(result[0]) + arg) < 0:
                return 'no'
            else:            
                self.cursor.execute("UPDATE %s SET `gp` = `gp` + %d WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, int(arg), aid))
                self.conn.commit()            
                self.cursor.execute("SELECT gp FROM %s WHERE `aid` = '%s'" % (BellisEnv.TABLE_AVATAR_NAME, aid))
                result = self.cursor.fetchall()[0]
                return result[0]

    def getChatRoomList(self, region):
        self.cursor.execute("SELECT * FROM %s WHERE `region` = '%s'" % (BellisEnv.TABLE_CHAT_ROOM, region))
        result = self.cursor.fetchall()
        return result

    def createChatRoom(self, region, place, name, owner, house, interior, currentuser, maxuser):
        self.cursor.execute("INSERT INTO `%s` (`id`,`region`,`place`,`name`,`owner`,`house`,`interior`,`currentuser`,`maxuser`) VALUES (NULL,'%s','%d','%s','%d','%d','%d','%d','%d')" % (BellisEnv.TABLE_CHAT_ROOM, region, place, unicode(name,'euckr').encode('utf8'), owner, house, interior, currentuser, maxuser))
        self.conn.commit()

    def loseConnection(self):
        self.conn.close()

    getInstance = classmethod(getInstance)
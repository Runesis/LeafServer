# -*- coding:utf8 -*-

from twisted.internet import reactor, protocol
from bellislib import *
from bellisenv import *
from struct import *

import random
import sys

class ChatTownFactory(protocol.ServerFactory):
    clients = []
    def connectionMade(self):
        print '    * CHATTOWN *  Connection accepted from %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.append(self)
        print '    * CHATTOWN *  %s user(s) connected in the world' % (len(self.factory.clients))
    def dataReceived(self, data):
        pass
    def clientConnectionLost(self, reason):
        print '    * CHATTOWN *  Connection closed by %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.remove(self)
        print '    * CHATTOWN *  %s user(s) connected in the world' % (len(self.factory.clients))

class LoginSocketProtocol(protocol.Protocol):
    createRoomNumber = 0

    def connectionMade(self):
        agentCode = 7
        packetBody = pack('ll', 1, 1) # Sending packet to Login server : LoginCode, ChatTownCode
        self.transport.write(pack('hh', agentCode, len(packetBody)) + packetBody)
    def connectionLost(self, reason):
        pass
    def dataReceived(self, data):
        self.parser(data)
    def packetDump(self, data):
        dumpPacket = ''
        for x in range(len(data)):
            dumpPacket = dumpPacket + '%02x' % (ord(data[x])) + ' '
        return dumpPacket

    def chat(self, agentCode, senderuid, message):
        opcode = 8
        writePacketBody = pack('ll', opcode, int(senderuid))
        writePacketBody = writePacketBody + message

        self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid + 'REGION')

    def parser(self, data):
        senderuid = data[-6:]
        agentCode = (unpack('h',data[:2]))[0]

        bodyLength = (unpack('h',data[2:4]))[0]
        bodyPacket = data[4:]

        if BellisEnv.DEBUG_MODE == True:
            print '    * CHATTOWN-DEBUG *  onReceived() - [Total %s byte(s) / Agent code : %s / Body length : %s] %s' % (len(data),agentCode,bodyLength,self.packetDump(bodyPacket))

        if agentCode == 11: # ChatTown Main Level
            controlType = unpack('l', bodyPacket[0:4])[0]

            print '    * CHATTOWN-DEBUG *  Control type - %d' % (controlType)
            #print 'debug-bodyp:%s' % bodyPacket[8:len(bodyPacket)-6]   

            if controlType == 0: # entering the room
                pass
                #replyControlType = 0
                #writePacketBody = pack('l5s18slllll', replyControlType, '\x00\x00\x00\x00\x00', '운영자', 0, 0, 0, 0, int(senderuid))
                #self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid)

                #writePacketBody = '\x01\x00\x00\x00'
                #self.transport.write(pack('hh', 11, len(writePacketBody)) + writePacketBody + senderuid)

                #print 'hahahaha'
            
            elif controlType == 1: # request create the room
                self.createRoomNumber = unpack('h', bodyPacket[4:6])[0]
                print '    * CHATTOWN-DEBUG *  Creating Room No. %d' % (self.createRoomNumber+1)

                replyControlType = 4
                writePacketBody = pack('l2s', replyControlType, bodyPacket[4:6])
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid)

                # TODO
                #replyControlType = 3
                #writePacketBody = pack('l1s2s', replyControlType, '\x00', bodyPacket[4:6]) + '\x02'
                #self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid + 'REGION')

            elif controlType == 2: # cancel create the room
                replyControlType = 5
                writePacketBody = pack('l', replyControlType)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid)

            elif controlType == 3: # receive information of the room
                print self.createRoomNumber

                replyControlType = 6

                createRoomInteriorType = bodyPacket[6:7]
                createRoomUserLimit = bodyPacket[5:6]
                createRoomHouseType = bodyPacket[4:5]

                if createRoomHouseType == '\x85':
                    print random.randint(0, 7)
                    createRoomHouseType = chr(0)

                createRoomPrivateType = bodyPacket[7:8]
                createRoomName = bodyPacket[8:len(bodyPacket)-6]

                writePacketBody = pack('lh1s1s1s1s1s1s', replyControlType, self.createRoomNumber, '\xff', '\x03', '\x00', createRoomHouseType, createRoomUserLimit, chr(0)) + createRoomName
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody + senderuid + 'CREATE_ROOM')

            elif controlType == 4: # receive chatting message
                self.chat(agentCode, senderuid, bodyPacket[4:len(bodyPacket)-6])

            else:
                pass

        elif agentCode == 7: # for servers
            serverTypeCode = unpack('l', bodyPacket[:4])[0]
            controlType = unpack('l', bodyPacket[4:8])[0]

            if serverTypeCode == 1: # ChatTown Server
                if controlType == 0: # Login failed.
                    print '    * CHATTOWN *  Server ID or PASSWORD is incorrect!!!'
                    self.transport.loseConnection()
                    # TODO  write log, disconnect
            else:
                print '    * CHATTOWN *  Incorrect server type. type : %s' % (serverTypeCode)

        else:
            print '    * CHATTOWN *  Unknown agent code was detected - %s' % (agentCode)
            print '    * CHATTOWN *  [FULL CODE] %s' % (self.packetDump(data))
            # TODO  write log, disconnect

class LoginSocketFactory(protocol.ReconnectingClientFactory):
    protocol = LoginSocketProtocol
    maxDelay = 5

    def startedConnecting(self, connector):
        print '    * CHATTOWN-LOGIN *  Connecting to Login server...'
    def buildProtocol(self, addr):
        self.resetDelay()
        print '    * CHATTOWN-LOGIN *  Successfully connected to Login server.'
        p = self.protocol()
        p.factory = self
        return p
    def clientConnectionLost(self, connector, reason):
        print '    * CHATTOWN-LOGIN *  Login server connection is lost. Retry after 5 seconds.'
        self.retry(connector)
    def clientConnectionFailed(self, connector, reason):
        print '    * CHATTOWN-LOGIN *  Connection is failed. Retry after 5 seconds.'
        self.retry(connector)

# Configuration
ChatTownServerPort = 35000
LoginServerPort = 33000

# Implementation
bellis.motd()
print '    * NOTICE *  ChatTown server is initializing...'
print '    * NOTICE *  Listening on port %s' % (ChatTownServerPort)

try:
    reactor.listenTCP(ChatTownServerPort, ChatTownFactory())
    print '    * NOTICE *  ChatTown server was initialized successfully, Working...'
    print ''
    reactor.connectTCP("localhost", LoginServerPort, LoginSocketFactory())
    reactor.run()
except:
    print '    * NOTICE *  Get a exception : %s' % (sys.exc_info()[1])
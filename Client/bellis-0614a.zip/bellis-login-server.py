# -*- coding:utf8 -*-

from twisted.internet import protocol, reactor
from bellislib import *
from account import *
from session import *
from struct import *   
from threading import *
from math import *
import time

class TimerThread(Thread):
    runningFlag = 1

    def __init__(self, server, fpInterval, gpInterval):
        Thread.__init__(self)
        self.server = server
        self.counter = 0
        self.fpInterval = fpInterval
        self.gpInterval = gpInterval
    
    def run(self):
        while 1:
            if self.runningFlag == 0:
                break
            time.sleep(1)
            self.clock()
    
    def brk(self):
        self.runningFlag = 0

    def clock(self):
        if self.counter % self.gpInterval == 0:
            self.server.updateConnectingBonus()
            
        elif self.counter % self.fpInterval == 0:
            self.server.updateTotalTime()
            
        self.counter = self.counter + 1

class LoginProtocol(protocol.Protocol):
    ticket = None
    t = None
    startTime = 0
    endTime = 0
    totalGP = 0

    def connectionMade(self):
        self.ticket = sessionMgr.createSession(self)
        self.t = TimerThread(self, BellisEnv.FP_BONUS_INTERVAL, BellisEnv.GP_BONUS_INTERVAL)

        print '    * LOGIN *  Connection accepted from %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.append(self)
        print '    * LOGIN *  %s account(s) connected in the world' % (len(self.factory.clients))

    def dataReceived(self, data):
        self.parser(data)

    def connectionLost(self, reason):
        if self.ticket.sessionType == 'server':
            self.factory.servers[int(self.ticket.avatarName)] = None

        if (self.t.isAlive()):
            self.t.brk()
            self.t.join()

        if self.ticket.region == None:
            pass
        elif self.ticket.region == 'WorldMap':
            pass
        else:
            opcode = self.getOpCode(None, self.ticket.region, 'removeuser')

            rlist = sessionMgr.getSameRegionUserSession(self.ticket.region)
            writePacketBody = pack('ll', opcode, int(self.ticket.uId))

            for x in range(len(rlist)):
                rlist[x].pSock.transport.write(pack('hh', self.getAgentByRegion(self.ticket.region), len(writePacketBody)) + writePacketBody)

        sessionMgr.removeSessionBySocketObject(self)
        self.ticket = None

        print '    * LOGIN *  Connection closed by %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.remove(self)
        print '    * LOGIN *  %s account(s) connected in the world' % (len(self.factory.clients))

    def updateTotalTime(self):
        accountMgr.updateTotalTimeByAID(self.ticket.aId)
        print '    * TIMER *  FP BONUS to AID #%s' % (self.ticket.aId)

    def updateConnectingBonus(self):
        accountMgr.updateTotalTimeByAID(self.ticket.aId)
        print '    * TIMER *  Update Total Time to AID #%s' % (self.ticket.aId)
        self.totalGP = self.totalGP + BellisEnv.GP_PER_HOUR

    def updateLastLogin(self):
        accountMgr.updateLastLoginDate(self.ticket.aId)

    def isGaveVisitGP(self):
        return accountMgr.updateVisitGP(self.ticket.aId)

    def packetDump(self, data):
        dumpPacket = ''
        for x in range(len(data)):
            dumpPacket = dumpPacket + '%02x' % (ord(data[x])) + ' '
        dumpPacket = dumpPacket + ' [Length:%d]' % (len(data))
        return dumpPacket

    # CLIENT -> SERVER
    def getCommand_0A(self, controlType, region):
        if region == 'MainStreet':
            if controlType == 0:
                return 'chat'
        elif region == 'Office':
            if controlType == 0:
                return 'chat'
        elif region == 'DressShop':
            if controlType == 0:
                return 'chat'
            elif controlType == 1:
                return 'listitem'
            elif controlType == 2:
                return 'selectitem'
        elif region == 'DressShop2':
            if controlType == 0:
                return 'chat'
            elif controlType == 1:
                return 'listitem'
            elif controlType == 2:
                return 'selectitem'
        elif region == 'CardShop':
            if controlType == 0:
                return 'chat'
            elif controlType == 1:
                return 'listitem'
            elif controlType == 2:
                return 'selectitem'
            elif controlType == 3:
                return 'buyitem'
        elif region == 'AccessoryShop':
            if controlType == 0:
                return 'chat'
            elif controlType == 1:
                return 'listitem'
            elif controlType == 2:
                return 'selectitem'
        elif region == 'HairShop':
            if controlType == 0:
                return 'chat'
            elif controlType == 1:
                return 'listitem'
            elif controlType == 2:
                return 'selectitem'
        elif region == 'EventHall':
            if controlType == 0:
                return 'chat'
        elif region == 'ChatRegion':
            if controlType == 0:
                return 'chat'
        elif region == 'ChatRegion2':
            if controlType == 0:
                return 'chat'
        elif region == 'KnightsRegion':
            if controlType == 0:
                return 'chat'
        elif region == 'D1Region':
            if controlType == 0:
                return 'chat'
        elif region[0:3] == 'D1_':
            if controlType == 202:
                return 'chat'
        else:
            print ' * getCommand_OA() - Unknown command.'
            return 0

    def getAgentByRegion(self, region):
        if region == 'MainStreet':
            return 10
        elif region == 'Office':
            return 10
        elif region == 'DressShop':
            return 10
        elif region == 'DressShop2':
            return 10
        elif region == 'CardShop':
            return 10
        elif region == 'AccessoryShop':
            return 10
        elif region == 'HairShop':
            return 10
        elif region == 'EventHall':
            return 10
        elif region == 'ChatRegion':
            return 10
        elif region == 'ChatRegion2':
            return 10
        elif region == 'KnightsRegion':
            return 10
        elif region == 'D1Region':
            return 10
        elif region[0:3] == 'D1_':
            return 10
        elif region == 'SpeechHall':
            return 11
        elif region == 'SeminarHall':
            return 11
        elif region[0:3] == 'CT_':
            return 11
        elif region[0:3] == 'KT_':
            return 11        

    # GET CONTROL(OP) CODE BY REGION
    # SERVER -> CLIENT
    def getOpCode(self, agent, region, command):
        if agent == None:
            agent = self.getAgentByRegion(region)

        if command == 'selectitem':
            if agent == 10:
                if region == 'CardShop':
                    return 8            

        if command == 'listitem':
            if agent == 10:
                if region == 'CardShop':
                    return 7
                elif region == 'DressShop':
                    return 6
                elif region == 'DressShop2':
                    return 6
                elif region == 'AccessoryShop':
                    return 7
                elif region == 'HairShop':
                    return 7
        if command == 'buyitem':
            if agent == 10:
                if region == 'CardShop':
                    return 10
        if command == 'chat':
            if agent == 10:
                if region == 'MainStreet':
                    return 5
                elif region == 'Office':
                    return 3
                elif region == 'DressShop':
                    return 5
                elif region == 'DressShop2':
                    return 5
                elif region == 'CardShop':
                    return 6
                elif region == 'AccessoryShop':
                    return 6
                elif region == 'HairShop':
                    return 6
                elif region == 'EventHall':
                    return 5
                elif region == 'ChatRegion':
                    return 6
                elif region == 'ChatRegion2':
                    return 6
                elif region == 'KnightsRegion':
                    return 6
                elif region == 'D1Region':
                    return 6
                elif region[0:3] == 'D1_':
                    return 209
                else:
                    return 0

            elif agent == 11:
                if region == 'SpeechHall':
                    return 3
                elif region == 'SeminarHall':
                    return 3
                elif region[0:3] == 'CT_':
                    return 1
                elif region[0:3] == 'KT_':
                    return 1
                else:
                    return 1
            else:
                pass

        elif command == 'adduser':
            if agent == 10:
                if region == 'MainStreet':
                    return 11
                elif region == 'Office':
                    return 1
                elif region == 'DressShop':
                    return 1
                elif region == 'DressShop2':
                    return 1
                elif region == 'CardShop':
                    return 1
                elif region == 'AccessoryShop':
                    return 1
                elif region == 'HairShop':
                    return 1
                elif region == 'EventHall':
                    return 3
                elif region == 'ChatRegion':
                    return 4
                elif region == 'ChatRegion2':
                    return 4
                elif region == 'KnightsRegion':
                    return 4
                elif region == 'D1Region':
                    return 4
                elif region[0:3] == 'D1_':
                    return 202
                else:
                    return 0

            elif agent == 11:
                if region == 'SpeechHall':
                    return 3
                elif region == 'SeminarHall':
                    return 3
                elif region[0:3] == 'CT_':
                    return 1
                elif region[0:3] == 'KT_':
                    return 1
                else:
                    return 1
            else:
                pass

        elif command == 'removeuser':
            if agent == 10:
                if region == 'MainStreet':
                    return 12
                elif region == 'Office':
                    return 2
                elif region == 'DressShop':
                    return 2
                elif region == 'DressShop2':
                    return 2
                elif region == 'CardShop':
                    return 2
                elif region == 'AccessoryShop':
                    return 2
                elif region == 'HairShop':
                    return 2
                elif region == 'EventHall':
                    return 4
                elif region == 'ChatRegion':
                    return 5
                elif region == 'ChatRegion2':
                    return 5
                elif region == 'KnightsRegion':
                    return 5
                elif region == 'D1Region':
                    return 5
                elif region[0:3] == 'D1_':
                    return 203
                else:
                    return 0

            elif agent == 11:
                if region == 'SpeechHall':
                    return 4
                elif region == 'SeminarHall':
                    return 4
                elif region[0:3] == 'CT_':
                    return 2
                elif region[0:3] == 'KT_':
                    return 2
                else:
                    return 2
            else:
                pass
        else:
            print '    * LOGIN *  Unknown command.'
            return 0

    def chat(self, agent, ticket, message):
        opcode = self.getOpCode(None, ticket.region, 'chat')

        rlist = sessionMgr.getSameRegionUserSession(ticket.region)
        writePacketBody = pack('ll', opcode, int(ticket.uId)) + message

        for x in range(len(rlist)):
            rlist[x].pSock.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)

    def listitem(self, agent, ticket, restpacket):
        opcode = self.getOpCode(None, ticket.region, 'listitem')

        if ticket.region == 'CardShop':
            writePacketBody = pack('l', opcode)

            cPacket = ''
            cData = accountMgr.loadCardShopData(restpacket[0])

            for x in range(len(cData)):
                cPacket = cPacket + pack('h',int((cData[x])[0])) + '\x03\x00'

            writePacketBody = writePacketBody + pack('1s', chr(len(cData))) + cPacket
            
            self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)
        else:
            pass

    def buyitem(self, agent, ticket, restpacket):
        opcode = self.getOpCode(None, ticket.region, 'buyitem')

        if ticket.region == 'CardShop':
            idx = unpack('h',restpacket[0:2])

            result = accountMgr.buyCardItem(self.ticket.aId, idx[0])
            
            if result == 0:
                writePacketBody = pack('ll', 0, 2)
                self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)
            else:
                writePacketBody = pack('l', opcode)
                writePacketBody = writePacketBody + pack('lhhl', result[1], idx[0], 3, result[0])
                self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)

                self.listitem(agent, ticket, result[2])

    def selectitem(self, agent, ticket, restpacket):
        opcode = self.getOpCode(None, ticket.region, 'selectitem')

        if ticket.region == 'CardShop':

            idx = unpack('h',restpacket[0:2])

            result = accountMgr.getCardInfo(idx[0])

            price = result[2]
            quantity = result[3]

            writePacketBody = pack('l', opcode)
            writePacketBody = writePacketBody + restpacket + pack('ll', price, quantity)
           
            self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)
        else:
            pass

    def addUserList(self, agent, ticket):
        opcode = None

        opcode = self.getOpCode(agent, ticket.region, 'adduser')
        
        rlist = sessionMgr.getSameRegionUserSession(ticket.region)

        for x in range(len(rlist)):
            print ' * AddListItem [User #%s]' % (rlist[x].uId)
            writePacketBody = pack('ll18s', opcode, int(rlist[x].uId), rlist[x].avatarName)
            self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)

        #writePacketBody = pack('ll18s', opcode, int(ticket.uId), ticket.avatarName)
        #self.transport.write(pack('hh', agent, len(writePacketBody)) + writePacketBody)

    def parser(self, data):
        agentCode = (unpack('h',data[:2]))[0]
        bodyLength = (unpack('h',data[2:4]))[0]
        bodyPacket = data[4:]

        if BellisEnv.DEBUG_MODE == True:
            print '    * LOGIN-DEBUG *  [Total %s byte(s) / Agent code : %s / Body length : %s] %s' % (len(data),agentCode,bodyLength,self.packetDump(bodyPacket))

        if agentCode == 0: # Connection level
            controlType = unpack('h', bodyPacket[:2])[0]
            controlAgent = unpack('h', bodyPacket[2:4])[0]

            if controlType == 1: # hello?
                writePacketBody = pack('hh', 2, controlAgent)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

                if controlAgent == 11:
                    if (self.ticket.region)[0:3] == 'CT_':
                        chatroomlist = accountMgr.getChatRoomList(self.ticket.region)

                        for x in range(len(chatroomlist)):
                            writePacketBody = pack('lh1s1s1s1s1s1s', 6, int((chatroomlist[x])[2]), '\xff', '\x03', '\x00', chr((chatroomlist[x])[5]), chr((chatroomlist[x])[7]), chr((chatroomlist[x])[8])) + unicode((chatroomlist[x])[3],'utf8').encode('euckr')
                            self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

                    if (self.ticket.region)[3:7] == 'Snow':
                        print 'snow'
                        Weather = 'Snow\x00'
                        self.transport.write(pack('hhl', 11, len(Weather)+4, 9) + Weather)
                    elif (self.ticket.region)[3:6] == 'Sea':
                        print 'sea'
                        Weather = 'SeaSnow\x00'
                        self.transport.write(pack('hhl', 11, len(Weather)+4, 9) + Weather)
                    elif (self.ticket.region)[3:8] == 'Plain':
                        print 'plain'
                        Weather = 'Plain\x00'
                        self.transport.write(pack('hhl', 11, len(Weather)+4, 9) + Weather)
                    else:
                        pass
                    
                    self.addUserList(controlAgent, self.ticket)

                if controlAgent == 10:
                    # ChatTown Agent Release
                    #ss = sessionMgr.selectSession(self)

                    if (self.ticket.region)[0:3] == 'CT_':
                        print 'ChatTown'
                        self.transport.write(pack('hhl', 10, 4, 4))

                    elif (self.ticket.region)[0:3] == 'KT_':
                        print 'KnightsRegion'
                        self.transport.write(pack('hhl', 10, 4, 4))

                    elif (self.ticket.region) == 'SpeechHall':
                        self.transport.write(pack('hhl', 10, 4, 0))

                    elif (self.ticket.region) == 'SeminarHall':
                        self.transport.write(pack('hhl', 10, 4, 1))

                    elif (self.ticket.region) == None:
                        pass

                    elif (self.ticket.region) == 'WorldMap':
                        pass

                    else:
                        self.addUserList(controlAgent, self.ticket)

            elif controlType == 4: # quit
                writePacketBody = pack('hh', 4, controlAgent)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                #sessionMgr.removeSessionBySocketObject(self)

        elif agentCode == 1: # Main agent level
            clientVersionCode = unpack('l', bodyPacket[:4])[0]
            controlType = unpack('l', bodyPacket[4:8])[0]
            unknownPacket = 0
            if controlType == 0: # Connect
                writePacketBody = pack('llh24s',clientVersionCode,controlType,unknownPacket,BellisEnv.NOTICE_INTRO)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

            elif controlType == 1: # Login Attempt
                recvAccountID_Length = ord(unpack('c', bodyPacket[8])[0])
                recvAccountID = unpack('%ds' % (recvAccountID_Length), bodyPacket[9:9+recvAccountID_Length])[0]
                recvAccountPassword = (bodyPacket[9+recvAccountID_Length:]).strip('\x00')

                authResult = accountMgr.auth(recvAccountID, recvAccountPassword)

                if authResult != 0: # confirm user session
                    sessionMgr.confirmUserSession(self, authResult)

                    writePacketBody = pack('l',clientVersionCode) + accountMgr.getAccountDataForLogin(sessionMgr.selectSession(self).uId)
                    writePacketHeader = pack('hh',agentCode,len(writePacketBody))

                    self.transport.write(writePacketHeader + writePacketBody)

                else: # id or password incorrect
                    writePacketBody = pack('lll',clientVersionCode,1,14)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

            elif controlType == 3: # Join
                writePacketBody = pack('ll', clientVersionCode, 0) + unicode(BellisEnv.NOTICE_JOIN, 'utf-8').encode('euc-kr') + '\x00'
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

            elif controlType == 4: # check ID
                result = accountMgr.isExistsAccountID(bodyPacket[8:])

                if result == 1:
                    op = 0
                else:
                    op = 12

                writePacketBody = pack('lll', clientVersionCode, 1, op)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)                

            elif controlType == 5: # Join Apply
                requestId = bodyPacket[8:24].strip('\x00')
                requestName = bodyPacket[24:34].strip('\x00')
                requestPassword = bodyPacket[44:60].strip('\x00')

                if bodyPacket[70] == '\x00':
                    requestGender = 'M'
                else: 
                    requestGender = 'F'

                if accountMgr.isExistsAccountID(requestId) == 1:
                    writePacketBody = pack('lll', clientVersionCode, 1, 12)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                #elif accountMgr.isValidAccountID(requestId) == 0:
                #    writePacketBody = pack('lll', clientVersionCode, 1, 12)
                #    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                else:
                    print requestName, self.packetDump(requestName)
                    accountMgr.signup(requestId, requestPassword, requestName, requestGender)

                    authResult = accountMgr.auth(requestId, requestPassword)
                    sessionMgr.confirmUserSession(self, authResult)

                    writePacketBody = pack('l',clientVersionCode) + accountMgr.getAccountDataForLogin(sessionMgr.selectSession(self).uId)
                    writePacketHeader = pack('hh',agentCode,len(writePacketBody))

                    self.transport.write(writePacketHeader + writePacketBody)

            elif controlType == 6: # Create Avatar Apply
                requestCharacter = bodyPacket[8]
                requestAvatarName = bodyPacket[9:31].strip('\x00')

                acount = accountMgr.getAvatarCount(self.ticket.uId)
                print acount
                result = accountMgr.isExistsAvatarName(requestAvatarName)

                if result == 1:
                    op = 55
                    writePacketBody = pack('lll', clientVersionCode, 1, op)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                
                elif acount == 3:
                    op = 54
                    writePacketBody = pack('lll', clientVersionCode, 1, op)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)                    

                else:
                    writePacketBody = pack('l',clientVersionCode) + accountMgr.createAvatar(self.ticket.uId, requestCharacter, requestAvatarName)
                    writePacketHeader = pack('hh',agentCode,len(writePacketBody))
                    self.transport.write(writePacketHeader + writePacketBody)                    

            elif controlType == 7: # Select avatar and Make Visit GP
                selectedAvatarIndex = int(ord(bodyPacket[8:9]))
                sessionMgr.writeAvatarInformation(self, accountMgr.getAIDByAOrder(sessionMgr.selectSession(self).uId, selectedAvatarIndex), accountMgr.getAvatarNameByAOrder(sessionMgr.selectSession(self).uId, selectedAvatarIndex))

                self.updateLastLogin()

                if self.isGaveVisitGP() == 0:
                    writePacketBody = pack('lllll', clientVersionCode, 6, 0, BellisEnv.VISIT_GP, 0)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

                self.startTime = time.time()
                ######## update gp,fp
                self.t.start()

                writePacketBody = pack('ll',clientVersionCode, 0) + accountMgr.getAvatarData(sessionMgr.selectSession(self).aId)
                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                
                #print 'controlType 7 finish'

            elif controlType == 9: # request quit
                self.endTime = time.time()
                self.t.brk()
                self.t.join()

                playingTime = floor(self.endTime - self.startTime)

                writePacketBody = pack('llllll',clientVersionCode, 7, playingTime, 0, self.totalGP, 7919)

                self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)
                self.transport.loseConnection()

                #self.transport.write('\x00\x00\x04\x00\x04\x00\x03\x00\x00\x00\x04\x00\x04\x00\x02\x00')
                #self.transport.write('\x00\x00\x04\x00\x04\x00\x01\x00')

            else:
                pass
        
        elif agentCode == 2: # delegate to worldmap server
            # WorldMap To Login
            if sessionMgr.selectSession(self).uId == accountMgr.getUIDBySID('worldmap'): # If sender is server
                
                ss = sessionMgr.selectSessionByUID(data[-6:])

                if ss != None:
                    #print data[0:len(data)-6]
                    #print self.packetDump(data[0:len(data)-6])
                    ss.pSock.transport.write(data[0:len(data)-6])

                    # Remove UserItem From Previous Region
                    print ' * Previous Region : %s' % (ss.region)

                    prevRegion = ss.region
                    ss.region = None

                    if prevRegion == None:
                        pass
                    elif prevRegion == 'WorldMap':
                        pass
                    else:
                        opcode = self.getOpCode(None, prevRegion, 'removeuser')

                        rlist = sessionMgr.getSameRegionUserSession(prevRegion)
                        writePacketBody = pack('ll', opcode, int(ss.uId))

                        for x in range(len(rlist)):
                            rlist[x].pSock.transport.write(pack('hh', self.getAgentByRegion(prevRegion), len(writePacketBody)) + writePacketBody)

                    newRegion = (unpack('32s',data[12:44])[0]).strip('\x00')

                    # Add UserItem To Current Region
                    print ' * Current Region : %s' % (newRegion)

                    if newRegion == None:
                        pass
                    elif newRegion == 'WorldMap':
                        pass
                    else:
                        opcode = self.getOpCode(None, newRegion, 'adduser')

                        rlist = sessionMgr.getSameRegionUserSession(newRegion)
                        writePacketBody = pack('ll18s', opcode, int(ss.uId), ss.avatarName)

                        for x in range(len(rlist)):
                            rlist[x].pSock.transport.write(pack('hh', self.getAgentByRegion(newRegion), len(writePacketBody)) + writePacketBody)

                    ss.region = newRegion

            # Login To WorldMap
            else:
                if self.factory.servers[0] != None: # worldmap server checking
                    wSock = self.factory.servers[0]
                    wSock.transport.write(data + str(sessionMgr.selectSession(self).uId))
                else:
                    self.transport.loseConnection()

        elif agentCode == 11: # ChatTown Channel Message
            # ChatTown To Login
            if sessionMgr.selectSession(self).uId == accountMgr.getUIDBySID('chattown'): # If sender is server
                if data[-6:] == 'REGION':
                    ss = sessionMgr.selectSessionByUID(data[-12:-6])
                    if ss != None:
                        rlist = sessionMgr.getSameRegionUserSession(ss.region)
                        for x in range(len(rlist)):
                            rlist[x].pSock.transport.write(data[0:len(data)-12])

                elif data[-11:] == 'CREATE_ROOM':
                    cregion = self.ticket.region
                    cplace = unpack('h',data[10:12])[0]
                    cname = data[18:-17]
                    cowner = self.ticket.aId
                    chouse = ord(data[15:16])
                    cinterior = ord('\x00')
                    ccurrentuser = ord(data[16:17])
                    cmaxuser = ord(data[17:18])

                    accountMgr.createChatRoom(cregion, cplace, cname, cowner, chouse, cinterior, ccurrentuser, cmaxuser)

                    ss = sessionMgr.selectSessionByUID(data[-17:-11])
                    if ss != None:
                        rlist = sessionMgr.getSameRegionUserSession(ss.region)
                        for x in range(len(rlist)):
                            rlist[x].pSock.transport.write(data[0:len(data)-17])

                else:
                    ss = sessionMgr.selectSessionByUID(data[-6:])
                    if ss != None:
                        print data[0:len(data)-6]
                        #print self.packetDump(data[0:len(data)-6])
                        ss.pSock.transport.write(data[0:len(data)-6])

            # Login To ChatTown
            else:
                if self.factory.servers[1] != None: # chattown server checking
                    wSock = self.factory.servers[1]
                    wSock.transport.write(data + sessionMgr.selectSession(self).uId)
                else:
                    pass

        elif agentCode == 10: # Channel Message
            if BellisEnv.DEBUG_MODE == True:
                print self.packetDump(bodyPacket)

            controlType = self.getCommand_0A(unpack('l', bodyPacket[:4])[0], self.ticket.region)

            if controlType == 'chat':
                self.chat(agentCode, self.ticket, bodyPacket[4:])
            elif controlType == 'listitem':
                self.listitem(agentCode, self.ticket, bodyPacket[4:])
            elif controlType == 'selectitem':
                self.selectitem(agentCode, self.ticket, bodyPacket[4:])
            elif controlType == 'insertitem':
                pass
            elif controlType == 'removeitem':
                pass
            elif controlType == 'buyitem':
                self.buyitem(agentCode, self.ticket, bodyPacket[4:])
            elif controlType == 'sellitem':
                pass
                #self.sellitem(agentCode, self.ticket, bodyPacket[4:])
            elif controlType == 'identify':
                pass
            else:
                print 'controlType is wrong!'

        elif agentCode == 7: # for servers
            controlType = unpack('l', bodyPacket[:4])[0]
            serverTypeCode = unpack('l', bodyPacket[4:8])[0]

            serverId = ''
            serverPassword = ''

            if controlType == 1: # Server Login
                self.factory.servers[serverTypeCode] = self
                print '    * LOGIN *  Other server is connecting to me...'
                if serverTypeCode == 0: # WorldMap Server
                    print '    * LOGIN *  WorldMap Server was identified.'
                    
                    serverId = BellisEnv.SERVER_WORLDMAP_ID
                    serverPassword = BellisEnv.SERVER_WORLDMAP_PASSWORD

                elif serverTypeCode == 1: # ChatTown Server
                    print '    * LOGIN *  ChatTown Server was identified.'
                    
                    serverId = BellisEnv.SERVER_CHATTOWN_ID
                    serverPassword = BellisEnv.SERVER_CHATTOWN_PASSWORD 
                
                else:
                    print '    * LOGIN *  Unknown server was detected.'

                authResult = accountMgr.auth(serverId, serverPassword)

                if authResult != 0: # confirm user session
                    sessionMgr.confirmServerSession(self, authResult, serverTypeCode)

                else: # id or password incorrect
                    self.factory.servers[serverTypeCode] = None

                    writePacketBody = pack('ll',0,0)
                    self.transport.write(pack('hh', agentCode, len(writePacketBody)) + writePacketBody)

        else:
            print '    * LOGIN *  Unknown agent code was detected - %s' % (agentCode)
            print '    * LOGIN *  [FULL CODE] %s' % (self.packetDump(data))
            # TODO  write log, disconnect

class LoginFactory(protocol.ServerFactory):
    protocol = LoginProtocol
    clients = []
    servers = [None] * 3
    servers[0] = None # WorldMap
    servers[1] = None # ChatTown
    servers[2] = None # Will be use
    accounts = []

# Configuration
LoginServerPort = 33000

# Implementation
bellis.motd()
print '    * NOTICE *  Login server is initializing...'
print '    * NOTICE *  Loading account table...'

accountMgr = AccountManager()
sessionMgr = SessionManager()

print '    * NOTICE *  Listening on port %s' % (LoginServerPort)

accountMgr.initializeAvatarData()

try:
    reactor.listenTCP(LoginServerPort, LoginFactory())
    print '    * NOTICE *  Login server was initialized successfully, Working...'
    print ''
    reactor.run()
except:
    print '    * NOTICE *  Get a exception. Check and fix it.'


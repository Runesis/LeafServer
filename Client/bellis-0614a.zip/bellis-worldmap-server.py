# -*- coding:utf8 -*-

from twisted.internet import reactor, protocol
from bellislib import *
from bellisenv import *
from struct import *

import sys

class WorldMapFactory(protocol.ServerFactory):
    clients = []
    def connectionMade(self):
        print '    * WORLDMAP *  Connection accepted from %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.append(self)
        print '    * WORLDMAP *  %s user(s) connected in the world' % (len(self.factory.clients))
    def dataReceived(self, data):
        pass
    def clientConnectionLost(self, reason):
        print '    * WORLDMAP *  Connection closed by %s:%s' % (self.transport.getPeer().host, self.transport.getPeer().port)
        self.factory.clients.remove(self)
        print '    * WORLDMAP *  %s user(s) connected in the world' % (len(self.factory.clients))

class LoginSocketProtocol(protocol.Protocol):
    def connectionMade(self):
        agentCode = 7
        packetBody = pack('ll', 1, 0) # Sending packet to Login server : LoginCode, WorldmapCode
        self.transport.write(pack('hh', agentCode, len(packetBody)) + packetBody)
    def connectionLost(self, reason):
        pass
    def dataReceived(self, data):
        self.parser(data)
    def packetDump(self, data):
        dumpPacket = ''
        for x in range(len(data)):
            dumpPacket = dumpPacket + '%02x' % (ord(data[x])) + ' '
        return dumpPacket
    def parser(self, data):
        senderuid = data[-6:]
        agentCode = (unpack('h',data[:2]))[0]
        bodyLength = (unpack('h',data[2:4]))[0]
        bodyPacket = data[4:]

        if BellisEnv.DEBUG_MODE == True:
            print '    * WORLDMAP-DEBUG *  [Total %s byte(s) / Agent code : %s / Body length : %s] %s' % (len(data),agentCode,bodyLength,self.packetDump(bodyPacket))

        if agentCode == 2: # Worldmap Main Level
            #print 'debug-bodyp:%s' % bodyPacket[8:len(bodyPacket)-6]
            requestRegion = (bodyPacket[8:len(bodyPacket)-6].split('/'))[-1]
   
            #print 'debug:%s' % (requestRegion)

            try:
                #print BellisEnv.REGION[requestRegion[0:len(requestRegion)-1]][1]

                packetBody = pack('ll32s30sll60s', 0, 0, requestRegion, unicode(BellisEnv.REGION[requestRegion[0:len(requestRegion)-1]][1], 'utf-8').encode('euc-kr'), 0, 0, BellisEnv.REGION[requestRegion[0:len(requestRegion)-1]][2])
                self.transport.write(pack('hh', agentCode, len(packetBody)) + packetBody + senderuid)
            except:
                print 'exception detected : %s %s' % (sys.exc_info()[0], sys.exc_info()[1])
                requestRegion = 'ChatRegion2\x00'
                packetBody = pack('ll32s30sll60s', 0, 0, requestRegion, BellisEnv.REGION[requestRegion[0:len(requestRegion)-1]][1], 0, 0, BellisEnv.REGION[requestRegion[0:len(requestRegion)-1]][2])
                self.transport.write(pack('hh', agentCode, len(packetBody)) + packetBody + senderuid)
        elif agentCode == 7: # for servers
            serverTypeCode = unpack('l', bodyPacket[:4])[0]
            controlType = unpack('l', bodyPacket[4:8])[0]

            if serverTypeCode == 0: # WorldMap Server
                if controlType == 0: # Login failed.
                    print '    * WORLDMAP *  Server ID or PASSWORD is incorrect!!!'
                    self.transport.loseConnection()
                    # TODO  write log, disconnect
            else:
                print '    * WORLDMAP *  Incorrect server type. '

        else:
            print '    * WORLDMAP *  Unknown agent code was detected - %s' % (agentCode)
            print '    * WORLDMAP *  [FULL CODE] %s' % (self.packetDump(data))
            # TODO  write log, disconnect

class LoginSocketFactory(protocol.ReconnectingClientFactory):
    protocol = LoginSocketProtocol
    maxDelay = 5

    def startedConnecting(self, connector):
        print '    * WORLDMAP-LOGIN *  Connecting to Login server...'
    def buildProtocol(self, addr):
        self.resetDelay()
        print '    * WORLDMAP-LOGIN *  Successfully connected to Login server.'
        p = self.protocol()
        p.factory = self
        return p
    def clientConnectionLost(self, connector, reason):
        print '    * WORLDMAP-LOGIN *  Login server connection is lost. Retry after 5 seconds.'
        self.retry(connector)
    def clientConnectionFailed(self, connector, reason):
        print '    * WORLDMAP-LOGIN *  Connection is failed. Retry after 5 seconds.'
        self.retry(connector)

# Configuration
WorldMapServerPort = 34000
LoginServerPort = 33000

# Implementation
bellis.motd()
print '    * NOTICE *  Worldmap server is initializing...'
print '    * NOTICE *  Listening on port %s' % (WorldMapServerPort)

try:
    reactor.listenTCP(WorldMapServerPort, WorldMapFactory())
    print '    * NOTICE *  Worldmap server was initialized successfully, Working...'
    print ''
    reactor.connectTCP("localhost", LoginServerPort, LoginSocketFactory())
    reactor.run()
except:
    print '    * NOTICE *  Get a exception : %s' % (sys.exc_info()[1])
# -*- coding:utf8 -*-

class AvatarData(object):
	__slots__ = ('avatarindex','accountindex','character','avatarname','avatarequip','avatarknights','avatargp','avatarfp','avatarinventory')

avatarFileName = '.\\save\\avatar.txt'

# 아바타 관리
class AvatarDataLoader:
	avatarIndexList = []
	avatarDataList = []
	def __init__(self):
		fp = open(avatarFileName,'r')
		temp = fp.read()
		fp.close()
		avatarDataArray = temp.split('\n')

		try:
			for x in range(len(avatarDataArray)):
				avatarDataArrayA = avatarDataArray[x].split('\t')
				ad = AvatarData()
				ad.avatarindex = avatarDataArrayA[0]
				ad.accountindex = avatarDataArrayA[1]
				ad.character = avatarDataArrayA[2]
				ad.avatarname = avatarDataArrayA[3]
				ad.avatarequip = avatarDataArrayA[4]
				ad.avatarknights = avatarDataArrayA[5]
				ad.avatargp = avatarDataArrayA[6]
				ad.avatarfp = avatarDataArrayA[7]
				ad.avatarinventory = avatarDataArrayA[8]
				self.avatarDataList.append(ad)
					
		except:
			out('error','아바타 데이터가 없거나 잘못된 데이터가 들어있습니다.')

	def flushAvatarData(self):
		while (len(self.avatarDataList) != 0):
			self.avatarDataList.pop()

	def getAvatarCountFrom(self,aid):
		count = 0
		for x in range(len(self.avatarDataList)):
			if self.avatarDataList[x].accountindex == aid:
				count = count + 1
			else:
				pass
		return count

	def getAvatarIndexes(self,aid):
		for x in range(len(self.avatarDataList)):
			if self.avatarDataList[x].accountindex == aid:
				self.avatarIndexList.append(self.avatarDataList[x].avatarindex)
			else:
				pass
		return self.avatarIndexList

	def getAvatarDataFromAvatarIndex(self,aid,aindex):
		resultAvatarPacket = ''		
		for x in range(len(self.avatarDataList)):
			if self.avatarDataList[x].accountindex == aid:
				resultAvatarPacket = resultAvatarPacket + pack('1s',self.avatarDataList[x].character)
				resultAvatarPacket = resultAvatarPacket + pack('22s',self.avatarDataList[x].avatarname)
				resultAvatarPacket = resultAvatarPacket + pack('5s','\x00'*5)
				itemList = self.avatarDataList[x].avatarequip.split(',')
				resultAvatarPacket = resultAvatarPacket + pack('hhhhhhhhhhhhhhhh',int(itemList[0]),int(itemList[1]),int(itemList[2]),int(itemList[3]),int(itemList[4]),int(itemList[5]),int(itemList[6]),int(itemList[7]),int(itemList[8]),int(itemList[9]),int(itemList[10]),int(itemList[11]),int(itemList[12]),int(itemList[13]),int(itemList[14]),int(itemList[15]))
				resultAvatarPacket = resultAvatarPacket + pack('24s','\x00'*24)
				resultAvatarPacket = resultAvatarPacket + pack('24s',self.avatarDataList[x].avatarknights)
				resultAvatarPacket = resultAvatarPacket + pack('l',int(self.avatarDataList[x].avatargp))
				resultAvatarPacket = resultAvatarPacket + pack('l',int(self.avatarDataList[x].avatarfp))
				resultAvatarPacket = resultAvatarPacket + pack('16s','\x00'*16)
				inventoryList = self.avatarDataList[x].avatarinventory.split(',')
				#아이템1 : inventoryList[0],[1]
				#아이템2 : inventoryList[2],[3]
				for y in range(35):
					try:
					#print inventoryList[2*(y+1)-2],inventoryList[2*(y+1)-1]
						resultAvatarPacket = resultAvatarPacket + pack('h',int(inventoryList[2*(y+1)-2]))
						resultAvatarPacket = resultAvatarPacket + pack('h',int(inventoryList[2*(y+1)-1]))
					except:
						resultAvatarPacket = resultAvatarPacket + '\x00\x00'

		if aindex == 0:
			return resultAvatarPacket[0:202]
		elif aindex == 1:
			return resultAvatarPacket[202:404]
		else:
			return resultAvatarPacket[404:606]


	def getAvatarDataFrom(self,aid):
		print '--- Function called getAvatarDataFrom'
		resultAvatarPacket = ''
		print self.avatarDataList
		for x in range(len(self.avatarDataList)):
			print '--- Looping start'
			if self.avatarDataList[x].accountindex == aid:
				resultAvatarPacket = resultAvatarPacket + pack('1s',self.avatarDataList[x].character)
				resultAvatarPacket = resultAvatarPacket + pack('22s',self.avatarDataList[x].avatarname)
				resultAvatarPacket = resultAvatarPacket + pack('5s','\x00'*5)
				itemList = self.avatarDataList[x].avatarequip.split(',')
				resultAvatarPacket = resultAvatarPacket + pack('hhhhhhhhhhhhhhhh',int(itemList[0]),int(itemList[1]),int(itemList[2]),int(itemList[3]),int(itemList[4]),int(itemList[5]),int(itemList[6]),int(itemList[7]),int(itemList[8]),int(itemList[9]),int(itemList[10]),int(itemList[11]),int(itemList[12]),int(itemList[13]),int(itemList[14]),int(itemList[15]))
				resultAvatarPacket = resultAvatarPacket + pack('24s','\x00'*24)
				resultAvatarPacket = resultAvatarPacket + pack('24s',self.avatarDataList[x].avatarknights)
				resultAvatarPacket = resultAvatarPacket + pack('l',int(self.avatarDataList[x].avatargp))
				resultAvatarPacket = resultAvatarPacket + pack('l',int(self.avatarDataList[x].avatarfp))
				resultAvatarPacket = resultAvatarPacket + pack('12s','\x00'*12)
				dummyPacketLength = 384-len(resultAvatarPacket)
		print '--- Looping end'
		resultAvatarPacket = resultAvatarPacket + '\x00'*(dummyPacketLength)
		return resultAvatarPacket
		
	def searchAvatarElement(self,aid,aindex,temp):
		avatarDataListTemp = []
		for x in range(len(self.avatarDataList)):
			if self.avatarDataList[x].accountindex == aid:
				avatarDataListTemp.append(eval('self.avatarDataList[x].'+temp))
		if aindex == 0:
			return avatarDataListTemp[0]
		elif aindex == 1:
			return avatarDataListTemp[1]
		else:
			return avatarDataListTemp[2]
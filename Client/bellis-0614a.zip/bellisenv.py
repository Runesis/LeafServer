# -*- coding:utf8 -*-

class BellisEnv():
    DEBUG_MODE = False

    DB_HOST = 'localhost'
    DB_NAME = 'bellis'
    DB_USER = 'root'
    DB_PASS = 'password'

    NOTICE_INTRO = 'Project Bellis'
    NOTICE_DICE = ''
    NOTICE_WORLDMAP = ''
    NOTICE_JOIN = 'Project Bellis\r\n\r\n이 서버는 초기 테스트 중입니다.\r\n따라서 지연이나 잦은 서버다운이 일어날 수 있습니다.\r\n\r\n회원가입시에는 아이디와 비밀번호만 서버에 저장됩니다.\r\n그 외의 항목은 기재하여도 서버에 저장되지 않습니다.\r\n비밀번호는 암호화되어 본인 외에는 알 수 없습니다.'

    SERVER_ACCOUNT_ID = 'login'
    SERVER_ACCOUNT_PASSWORD = 'bellis'

    SERVER_CHATTOWN_ID = 'chattown'
    SERVER_CHATTOWN_PASSWORD = 'bellis'

    SERVER_CHANNEL_ID = 'channel'
    SERVER_CHANNEL_PASSWORD = 'bellis'

    SERVER_WORLDMAP_ID = 'worldmap'
    SERVER_WORLDMAP_PASSWORD = 'bellis'

    TABLE_ACCOUNT_NAME = 'account'
    TABLE_AVATAR_NAME = 'avatar'
    TABLE_INVENTORY_NAME = 'inventory'
    TABLE_CARD_SHOP = 'cardshop'
    TABLE_CHAT_ROOM = 'chatroom'
    TABLE_DICE_ROOM = 'diceroom'

    VISIT_GP = 100
    GP_PER_HOUR = 50

    GP_NEWBIE = 100000

    FP_BONUS_INTERVAL = 60
    GP_BONUS_INTERVAL = 1800

    REGION = {'WorldMap':[1,'아노마라드 상공',''],
              'MainStreet':[1,'켈티카의 거리','/WorldMap'],
              'Office':[1,'네냐플마법학원','/MainStreet'],
              'DressShop':[1,'댄디캣 클래식','/MainStreet'],
              'DressShop2':[1,'댄디캣','/MainStreet'],
              'CardShop':[1,'매직카덴','/MainStreet'],
              'AccessoryShop':[1,'캐즈팝','/MainStreet'],
              'HairShop':[1,'실키필','/MainStreet'],
              'EventHall':[1,'프레쉬 센트','/WorldMap'],
              'SpeechHall':[1,'와글와글스피치','/EventHall'],
              'SeminarHall':[1,'세미나실','/EventHall'],
              'ChatRegion':[1,'북 하이아칸','/WorldMap'],
              'CT_Snow01':[1,'실버 호라이즌','WWWorldMap/ChatRegionChatRegion'],
              'CT_Snow02':[1,'화이트 크리스탈','WWWorldMap/ChatRegionChatRegion'],
              'CT_Snow03':[1,'퓨어 시린','WWWorldMap/ChatRegionChatRegion'],
              'CT_Snow04':[1,'윈트리 아이스','WWWorldMap/ChatRegionChatRegion'],
              'CT_Snow05':[1,'스노우 풀','WWWorldMap/ChatRegionChatRegion'],
              'CT_Plain01':[1,'샤이닝 브리즈','/ChatRegion'],
              'CT_Plain02':[1,'스위트 쟈스민','/ChatRegion'],
              'CT_Plain03':[1,'그린 에메랄드','/ChatRegion'],
              'ChatRegion2':[1,'남 하이아칸','/WorldMap'],
              'CT_Sea01':[1,'블루 사파이어','WorldMap/ChatRegion2atRegion2'],
              'CT_Sea02':[1,'헤이즐리 웨이브','WorldMap/ChatRegion2atRegion2'],
              'CT_Sea03':[1,'아쿠아 코럴','WorldMap/ChatRegion2atRegion2'],
              'CT_Sea04':[1,'블래싱 마린','WorldMap/ChatRegion2atRegion2'],
              'CT_Sea05':[1,'미스틱 머메이드','WorldMap/ChatRegion2atRegion2'],
              'CT_Plain04':[1,'매쉬 메리골드','/WorldMap/ChatRegion2ChatRegion2'],
              'CT_Plain05':[1,'엘핀 포레스트','/WorldMap/ChatRegion2ChatRegion2'],
              'CT_Plain06':[1,'블랜드 제피르','/WorldMap/ChatRegion2ChatRegion2'],
              'D1Region':[1,'주사위의 잔영','/WorldMap/WorldMap/WorldMap'],
              'D1_Ispin_1':[1,'주사위의 잔영: 이스핀 [1]','/D1Region'],
              'D1_Ispin_2':[1,'주사위의 잔영: 이스핀 [2]','/D1Region'],
              'D1_Ispin_3':[1,'주사위의 잔영: 이스핀 [3]','/D1Region'],
              'D1_Ispin_4':[1,'주사위의 잔영: 이스핀 [4]','/D1Region'],
              'D1_Nayatrei_1':[1,'주사위의 잔영: 나야트레이 [1]','/D1Region'],
              'D1_Nayatrei_2':[1,'주사위의 잔영: 나야트레이 [2]','/D1Region'],
              'D1_Nayatrei_3':[1,'주사위의 잔영: 나야트레이 [3]','/D1Region'],
              'D1_Nayatrei_4':[1,'주사위의 잔영: 나야트레이 [4]','/D1Region'],
              'D1_Cloe_1':[1,'주사위의 잔영: 클로에 [1]','/D1Region'],
              'D1_Cloe_2':[1,'주사위의 잔영: 클로에 [2]','/D1Region'],
              'D1_Cloe_3':[1,'주사위의 잔영: 클로에 [3]','/D1Region'],
              'D1_Cloe_4':[1,'주사위의 잔영: 클로에 [4]','/D1Region'],
              'D1_Mila_1':[1,'주사위의 잔영: 밀라 [1]','/D1Region'],
              'D1_Mila_2':[1,'주사위의 잔영: 밀라 [2]','/D1Region'],
              'D1_Mila_3':[1,'주사위의 잔영: 밀라 [3]','/D1Region'],
              'D1_Mila_4':[1,'주사위의 잔영: 밀라 [4]','/D1Region'],
              'D1_Tichiel_1':[1,'주사위의 잔영: 티치엘 [1]','/D1Region'],
              'D1_Tichiel_2':[1,'주사위의 잔영: 티치엘 [2]','/D1Region'],
              'D1_Tichiel_3':[1,'주사위의 잔영: 티치엘 [3]','/D1Region'],
              'D1_Tichiel_4':[1,'주사위의 잔영: 티치엘 [4]','/D1Region'],
              'D1_Anais_1':[1,'주사위의 잔영: 아나이스 [1]','/D1Region'],
              'D1_Anais_2':[1,'주사위의 잔영: 아나이스 [2]','/D1Region'],
              'D1_Anais_3':[1,'주사위의 잔영: 아나이스 [3]','/D1Region'],
              'D1_Anais_4':[1,'주사위의 잔영: 아나이스 [4]','/D1Region'],
              'D1_Benya_1':[1,'주사위의 잔영: 벤야 [1]','/D1Region'],
              'D1_Benya_2':[1,'주사위의 잔영: 벤야 [2]','/D1Region'],
              'D1_Benya_3':[1,'주사위의 잔영: 벤야 [3]','/D1Region'],
              'D1_Benya_4':[1,'주사위의 잔영: 벤야 [4]','/D1Region'],
              'KnightsRegion':[1,'레코르다블','/WorldMap'],
              'KT_Sea01':[1,'모험의 바다','/KnightsRegionhtsRegion'],
              'KT_Plain01':[1,'패왕의 대지','/KnightsRegionightsRegion'],
              'KT_Snow01':[1,'침묵의 설원','/KnightsRegionghtsRegion'],
              'KT_Sea02':[1,'도전의 바다','/KnightsRegionhtsRegion'],
              'KT_Sea03':[1,'황혼의 바다','/KnightsRegionhtsRegion'],
              'KT_Plain02':[1,'영광의 대지','/KnightsRegionightsRegion']
             }

    @staticmethod
    def __init__(self):
        pass

# -*- coding:utf8 -*-

class bellis:
    @staticmethod
    def motd():
        print ''
        print '>>>'
        print '>>>  Welcome to the Bellis, '
        print '>>>                   The Server Emulator Of A Softmax Online Service \'4LEAF\''
        print '>>>'
        print '>>>               by Jo@TNZ -- http://ell.springnote.com'
        print '>>>                         -- motivity@gmail.com'
        print '>>>'
        print '>>>'
        print '>>>                         CAUTION!!!'
        print '>>>'  
        print '>>>        THIS EMULATOR IS ALPHA DEVELOPMENT VERSION.'
        print '>>>        SO, VERY UNSTABLE DURING THE SERVER RUNNING.'
        print '>>>'
        print '>>>        IF YOU HAVE ANY QUESTIONS OR PROBLEMS,'
        print '>>>        PLEASE SEND AN E-MAIL TO ME OR'
        print '>>>        REPLY TO EVERYWHERE IN \'4LEAF\' CATEGORY OF MY SPRINGNOTE.'
        print '>>>'
        print '>>>        ENJOY THE 4LEAF AND HAVE A NICE DAY!!!'
        print '>>>'
        print ''
# -*- coding:utf8 -*-

from account import *
from bellisenv import *

import thread

class Session(object):
    __slots__ = ('sessionId', 'sessionType', 'avatarName', 'uId', 'aId', 'pSock', 'region')

class SessionManager:
    __lockObj = thread.allocate_lock()
    __st = None

    accountMgr = AccountManager()

    sessionList = []
    sessionCounter = 1

    def __new__(cls, *args, **kwargs):
        return cls.getInstance(cls, *args, **kwargs)

    def __init__(self):
        pass

    def getInstance(cls, *args, **kwargs):
        cls.__lockObj.acquire()
        try:
            if cls.__st is None:
                cls.__st = object.__new__(cls, *args, **kwargs)
        finally:
            cls.__lockObj.release()

        return cls.__st

    def createSession(self, pSock):
        ss = Session()
        ss.uId = None
        ss.aId = None
        ss.avatarName = None
        ss.sessionType = None
        ss.region = None
        ss.sessionId = self.sessionCounter
        self.sessionCounter = self.sessionCounter + 1
        ss.pSock = pSock
        self.sessionList.append(ss)

        print '    * SESSION *  Session #%d was successfully created.' % (self.sessionCounter-1)

        return ss

    # 세션 데이터가 커질 경우 잠재적인 지연문제가 있을 수 있음
    def selectSession(self, pSock):
        for x in range(len(self.sessionList)):
            if self.sessionList[x].pSock == pSock:        
                return self.sessionList[x]      
        return None      

    # 세션 데이터가 커질 경우 잠재적인 지연문제가 있을 수 있음
    def selectSessionByUID(self, uId):
        #print self

        for x in range(len(self.sessionList)):
            #print type(uId)
            #print type(self.sessionList[x].uId)
            if self.sessionList[x].uId == uId:        
                return self.sessionList[x]      
        return None             

    def getSameRegionUserSession(self, region):
        returnList = []

        for x in range(len(self.sessionList)):
            if self.sessionList[x].region == region:
                returnList.append(self.sessionList[x])

        return returnList

    def confirmUserSession(self, pSock, uId):
        ss = self.selectSession(pSock)
        
        if ss != None:
            ss.uId = uId
            ss.sessionType = 'user'
            print '    * SESSION *  Confirm session type to USER'
        else:
            print '    * SESSION *  Session NULL exception.'

        self.accountMgr.setOnline(uId)

    def confirmServerSession(self, pSock, uId, serverType):
        ss = self.selectSession(pSock)

        if ss != None:
            ss.uId = uId
            ss.sessionType = 'server'
            ss.avatarName = serverType

            print '    * SESSION *  Confirm session type to SERVER'
        else:
            print '    * SESSION *  Session NULL exception.'

        self.accountMgr.setOnline(uId)

    def writeAvatarInformation(self, pSock, aId, avatarName):
        ss = self.selectSession(pSock)

        if ss != None:
            ss.aId = aId
            ss.avatarName = avatarName
            print '    * SESSION *  Avatar #%s is entering to the Anomarad...' % (ss.aId)

    # 세션 데이터가 커질 경우 잠재적인 지연문제가 있을 수 있음
    def removeSessionByUId(self, uId):
        for x in range(len(self.sessionList)):
            if self.sessionList[x].uId == uId:        
                print '    * SESSION *  Session #%d was successfully removed.' % (self.sessionList[x].sessionId)

                del self.sessionList[x]

                self.accountMgr.setOffline(uId)

                break
        print self.sessionList

    # 세션 데이터가 커질 경우 잠재적인 지연문제가 있을 수 있음
    def removeSessionBySocketObject(self, pSock):       
        for x in range(len(self.sessionList)):
            if self.sessionList[x].pSock == pSock: 
                uId = self.sessionList[x].uId
                print '    * SESSION *  Session #%d was successfully removed.' % (self.sessionList[x].sessionId)

                del self.sessionList[x]

                if uId != None:
                    self.accountMgr.setOffline(uId)
                break
        
        print self.sessionList

    getInstance = classmethod(getInstance)
/*
MySQL Data Transfer
Source Host: localhost
Source Database: bellis
Target Host: localhost
Target Database: bellis
Date: 2009-06-13 ���� 7:00:26
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for account
-- ----------------------------
CREATE TABLE `account` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` varchar(16) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `name` varchar(12) DEFAULT NULL,
  `sex` enum('F','S','M') DEFAULT 'F',
  `avatarcount` smallint(1) unsigned DEFAULT '0',
  `birth` varchar(9) DEFAULT NULL,
  `publicbirth` enum('Y','N') DEFAULT 'Y',
  `telephone` varchar(11) DEFAULT NULL,
  `publictelephone` enum('Y','N') DEFAULT 'Y',
  `domaincode` smallint(1) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `profile` varchar(200) DEFAULT NULL,
  `passwordquestion` varchar(50) DEFAULT NULL,
  `passwordanswer` varchar(50) DEFAULT NULL,
  `joindate` date DEFAULT NULL,
  `online` enum('1','0') DEFAULT '0',
  `lastlogin` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=100024 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `account` VALUES ('100000', 'worldmap', 'f7cade80b7cc92b991cf4d2806d6bd78', 'WorldMap', 'S', '0', null, 'Y', null, 'Y', null, null, null, null, null, null, null, null, '1', null);
INSERT INTO `account` VALUES ('100001', 'chattown', 'f7cade80b7cc92b991cf4d2806d6bd78', 'ChatTown', 'S', '0', null, 'Y', null, 'Y', null, null, null, null, null, null, null, null, '1', null);

/*
MySQL Data Transfer
Source Host: localhost
Source Database: bellis
Target Host: localhost
Target Database: bellis
Date: 2009-06-13 ���� 7:00:35
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for avatar
-- ----------------------------
CREATE TABLE `avatar` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL,
  `aorder` enum('1','2','3') DEFAULT '1',
  `character` enum('0','1','2','3','4','5','6','128','129','130','131','132','133','134') DEFAULT '0',
  `nick` varchar(22) DEFAULT NULL,
  `knights` varchar(24) DEFAULT ' ',
  `gp` int(10) unsigned DEFAULT '0',
  `fp` int(10) unsigned DEFAULT '0',
  `bodyback` int(10) unsigned DEFAULT '0',
  `bodyfront` int(10) unsigned DEFAULT '0',
  `hair` int(10) unsigned DEFAULT '0',
  `hairacc` int(10) unsigned DEFAULT '0',
  `clothes` int(10) unsigned DEFAULT '0',
  `trousers` int(10) unsigned DEFAULT '0',
  `shoes` int(10) unsigned DEFAULT '0',
  `weapon` int(10) unsigned DEFAULT '0',
  `accessory1` int(10) unsigned DEFAULT '0',
  `accessory2` int(10) unsigned DEFAULT '0',
  `accessory3` int(10) unsigned DEFAULT '0',
  `accessory4` int(10) unsigned DEFAULT '0',
  `accessory5` int(10) unsigned DEFAULT '0',
  `accessory6` int(10) unsigned DEFAULT '0',
  `accessory7` int(10) unsigned DEFAULT '0',
  `accessory8` int(10) unsigned DEFAULT '0',
  `totaltime` bigint(20) unsigned DEFAULT '0',
  `lastlogin` datetime DEFAULT NULL,
  `visitgp` enum('1','0') DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=500040 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------

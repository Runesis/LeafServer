CREATE TABLE `account` (
  
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  
  `sid` varchar(16) DEFAULT NULL,
  
  `password` varchar(32) DEFAULT NULL,
  
  `name` varchar(12) DEFAULT NULL,
  
  `sex` enum('F','S','M') DEFAULT 'F',
  
  `avatarcount` smallint(1) unsigned DEFAULT '0',
  
  `birth` varchar(9) DEFAULT NULL,
  
  `publicbirth` enum('Y','N') DEFAULT 'Y',
  
  `telephone` varchar(11) DEFAULT NULL,
  
  `publictelephone` enum('Y','N') DEFAULT 'Y',
  
  `domaincode` smallint(1) DEFAULT NULL,
  
  `address1` varchar(50) DEFAULT NULL,
  
  `address2` varchar(100) DEFAULT NULL,
  
  `email` varchar(50) DEFAULT NULL,
  
  `profile` varchar(200) DEFAULT NULL,
  
  `passwordquestion` varchar(50) DEFAULT NULL,
  
  `passwordanswer` varchar(50) DEFAULT NULL,
  
  `joindate` date DEFAULT NULL,
  
  `online` enum('1','0') DEFAULT '0',
  
  PRIMARY KEY (`uid`)

) ENGINE=InnoDB AUTO_INCREMENT=100000 DEFAULT CHARSET=utf8;

CREATE TABLE `avatar` (
  `aid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT NULL,
  `aorder` enum('1','2','3') DEFAULT '1',
  `character` enum('0','1','2','3','4','5','6','128','129','130','131','132','133','134') DEFAULT '0',
  `nick` varchar(22) DEFAULT NULL,
  `knights` varchar(24) DEFAULT NULL,
  `gp` int(11) unsigned DEFAULT NULL,
  `fp` int(11) unsigned DEFAULT NULL,
  `bodyback` int(10) unsigned DEFAULT NULL,
  `bodyfront` int(10) unsigned DEFAULT NULL,
  `hair` int(10) unsigned DEFAULT NULL,
  `hairacc` int(10) unsigned DEFAULT NULL,
  `clothes` int(10) unsigned DEFAULT NULL,
  `trousers` int(10) unsigned DEFAULT NULL,
  `shoes` int(10) unsigned DEFAULT NULL,
  `weapon` int(10) unsigned DEFAULT NULL,
  `accessory1` int(10) unsigned DEFAULT NULL,
  `accessory2` int(10) unsigned DEFAULT NULL,
  `accessory3` int(10) unsigned DEFAULT NULL,
  `accessory4` int(10) unsigned DEFAULT NULL,
  `accessory5` int(10) unsigned DEFAULT NULL,
  `accessory6` int(10) unsigned DEFAULT NULL,
  `accessory7` int(10) unsigned DEFAULT NULL,
  `accessory8` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=500000 DEFAULT CHARSET=utf8;

CREATE TABLE `inventory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned DEFAULT NULL,
  `itemidx` int(10) unsigned DEFAULT NULL,
  `itemtype` int(10) unsigned DEFAULT NULL,
  `gettime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*
MySQL Data Transfer
Source Host: localhost
Source Database: bellis
Target Host: localhost
Target Database: bellis
Date: 2009-06-13 ���� 7:00:41
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for cardshop
-- ----------------------------
CREATE TABLE `cardshop` (
  `idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------

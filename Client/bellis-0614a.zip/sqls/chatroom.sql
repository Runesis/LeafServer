/*
MySQL Data Transfer
Source Host: localhost
Source Database: bellis
Target Host: localhost
Target Database: bellis
Date: 2009-06-13 ���� 7:00:48
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for chatroom
-- ----------------------------
CREATE TABLE `chatroom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region` varchar(50) DEFAULT NULL,
  `owner` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------

/*
MySQL Data Transfer
Source Host: localhost
Source Database: bellis
Target Host: localhost
Target Database: bellis
Date: 2009-06-13 ���� 7:00:52
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for inventory
-- ----------------------------
CREATE TABLE `inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned DEFAULT NULL,
  `itemidx` int(10) unsigned DEFAULT NULL,
  `itemtype` int(10) unsigned DEFAULT NULL,
  `gettime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------

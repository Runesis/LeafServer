# -*- coding:utf8 -*-

from twisted.enterprise import adbapi
from MySQLdb import _mysql
from bellisenv import *
from struct import *
import hashlib, thread

dbd = adbapi.ConnectionPool("MySQLdb", user=BellisEnv.DB_USER, passwd=BellisEnv.DB_PASS, host=BellisEnv.DB_HOST, db=BellisEnv.DB_NAME, cp_reconnect=1)
conn = dbd.connect()
cs = conn.cursor()

cs.execute("SELECT * FROM account")

rs = cs.fetchall()
print rs

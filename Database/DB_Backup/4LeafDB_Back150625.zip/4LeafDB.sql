-- --------------------------------------------------------
-- 호스트:                          192.168.56.101
-- 서버 버전:                        5.5.41-MariaDB-log - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  9.2.0.4947
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 4Leaf 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `4Leaf` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `4Leaf`;


-- 테이블 4Leaf.tbl_CardInfo 구조 내보내기
CREATE TABLE IF NOT EXISTS `tbl_CardInfo` (
  `f_CID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `f_Index` int(11) unsigned NOT NULL,
  `f_Type` tinyint(3) unsigned NOT NULL,
  `f_Rank` varchar(20) COLLATE utf8_bin NOT NULL,
  `f_Name` varchar(50) COLLATE utf8_bin NOT NULL,
  `f_Skill` varchar(20) COLLATE utf8_bin NOT NULL,
  `f_Ability` varchar(50) COLLATE utf8_bin NOT NULL,
  `f_BuyPrice` int(10) unsigned NOT NULL DEFAULT '0',
  `f_SellPrice` int(10) unsigned NOT NULL DEFAULT '0',
  `f_Quantity` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`f_CID`),
  KEY `CardIndex` (`f_Index`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 테이블 데이터 4Leaf.tbl_CardInfo:~98 rows (대략적) 내보내기
/*!40000 ALTER TABLE `tbl_CardInfo` DISABLE KEYS */;
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(1, 1, 3, 'Valuable', '기파랑', '지력 A', '1턴간 Int+4', 4100, 2050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(2, 2, 3, 'Normal', '노포크', '이동 C', '3턴간 Move+4', 980, 490, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(4, 3, 3, 'Normal', '닐라', '공격 C', '3턴간 Attack+4', 1250, 625, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(5, 4, 3, 'Normal', '라쉬카', '지력 C', '3턴간 Int+2', 980, 490, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(6, 5, 3, 'Valuable', '록슬리', '공격 A', '1턴간 공격 주사위 +2개', 4000, 2000, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(7, 6, 3, 'Normal', '롤랑', '방어 B', '2턴간 방어 주사위 +1개', 1500, 750, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(8, 7, 3, 'Normal', '리슐리외', '공격 B', '2턴간 공격 주사위 +1개', 2100, 1050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(9, 8, 3, 'Normal', '마르자나', '공격 B', '2턴간 공격 주사위 +1개', 3800, 1900, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(10, 9, 3, 'Normal', '마리아애슬린', '이동 B', '2턴간 이동 주사위 +1개', 1580, 790, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(11, 10, 3, 'Normal', '마법사', '이동 D', '1턴간 Move+4', 80, 40, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(12, 11, 3, 'Normal', '말콤', '이동 C', '3턴간 Move+4', 1320, 660, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(13, 12, 3, 'Normal', '무슬림', '이동 D', '1턴간 Move+4', 80, 40, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(14, 13, 3, 'Normal', '무카파', '방어 B', '2턴간 방어 주사위 +1개', 2230, 1115, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(15, 14, 3, 'Normal', '바시바조크', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(16, 15, 3, 'Normal', '바이올라', '방어 B', '2턴간 방어 주사위 +1개', 1550, 775, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(17, 16, 3, 'Normal', '바자', '이동 C', '3턴간 Move+4', 980, 490, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(18, 17, 3, 'Normal', '발라', '이동 B', '2턴간 이동 주사위 +1개', 2700, 1350, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(19, 18, 3, 'Valuable', '버몬트', 'Keeper', '2턴간 자신을 몬스터화', 14900, 7450, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(20, 19, 3, 'Valuable', '벨제부르', '공격 A', '1턴간 공격 주사위 +2개', 7150, 3575, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(21, 20, 3, 'Normal', '보르스', '공격 C', '3턴간 Attack+4', 1270, 635, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(22, 21, 3, 'Normal', '사피알딘', '공격 C', '3턴간 Attack+4', 1400, 700, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(23, 22, 3, 'Valuable', '살라딘', '순간이동', '1~15칸 사이를 랜덤하게 워프', 21500, 10750, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(24, 23, 3, 'Normal', '샤프리아르', '지력 B', '2턴간 Int+3', 1350, 675, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(25, 24, 3, 'Normal', '세시', '이동 C', '3턴간 Move+4', 950, 475, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(26, 25, 3, 'Valuable', '셰라자드', '팀지력+', '팀원들의 지력을 2턴간 +3', 21000, 10500, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(27, 26, 3, 'Normal', '솔져', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(28, 27, 3, 'Valuable', '시안', '방어 A', '1턴간 방어 주사위 +2개', 6300, 3150, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(29, 28, 3, 'Normal', '시즈', '이동 B', '2턴간 이동 주사위 +1개', 1900, 950, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(30, 29, 3, 'Normal', '심넬램버트', '공격 B', '2턴간 공격 주사위 +1개', 1720, 860, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(31, 30, 3, 'Normal', '아델라이데', '지력 B', '2턴간 Int+3', 1330, 665, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(32, 31, 3, 'Normal', '아두스베이', '이동 B', '2턴간 이동 주사위 +1개', 1800, 900, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(33, 32, 3, 'Normal', '알무파샤', '지력 B', '2턴간 Int+3', 2180, 1090, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(34, 33, 3, 'Normal', '알아샤', '지력 B', '2턴간 Int+3', 1600, 800, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(35, 34, 3, 'Normal', '알이스파니히', '방어 C', '3턴간 Defend+4', 660, 330, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(36, 35, 3, 'Normal', '알파라비', '이동 B', '2턴간 이동 주사위 +1개', 1580, 790, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(37, 36, 3, 'Normal', '알가지', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(38, 37, 3, 'Valuable', '알바티니', '방어 A', '1턴간 방어 주사위 +2개', 5000, 2500, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(39, 38, 3, 'Valuable', '얀지슈카', '공격 A', '1턴간 공격 주사위 +2개', 3650, 1825, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(40, 39, 3, 'Normal', '엘핀스톤', '공격 B', '2턴간 공격 주사위 +1개', 2100, 1050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(41, 40, 3, 'Normal', '오스만누리파샤', '방어 B', '2턴간 방어 주사위 +1개', 2280, 1140, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(42, 41, 3, 'Normal', '올리비에', '지력 B', '2턴간 Int+3', 1950, 975, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(43, 42, 3, 'Normal', '워락', '이동 D', '1턴간 Move+4', 80, 40, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(44, 43, 3, 'Normal', '이븐사이드', '방어 B', '2턴간 방어 주사위 +1개', 1550, 775, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(45, 44, 3, 'Normal', '이븐시나', '공격 B', '2턴간 공격 주사위 +1개', 2100, 1050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(46, 45, 3, 'Normal', '이슈탈', '방어 C', '3턴간 Defend+4', 750, 375, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(47, 46, 3, 'Normal', '자바카스', '방어 C', '3턴간 Defend+4', 830, 415, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(48, 47, 3, 'Normal', '제국나이트', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(49, 48, 3, 'Valuable', '죠안', '이동 A', '1턴간 이동 주사위 +2개', 5100, 2550, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(50, 49, 3, 'Normal', '죠엘', '공격 B', '2턴간 공격 주사위 +1개', 4400, 2200, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(51, 50, 3, 'Valuable', '지그문트', '이동 A', '1턴간 이동 주사위 +2개', 5200, 2600, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(52, 51, 3, 'Valuable', '철가면', 'Destroy', '2턴간 공격 주사위 최대값', 18500, 9250, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(53, 52, 3, 'Normal', '케이트호크', '지력 C', '3턴간 Int+2', 1200, 600, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(54, 53, 3, 'Normal', '크리스티나', '공격 B', '2턴간 공격 주사위 +1개', 1550, 775, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(55, 54, 3, 'Valuable', '크리스티앙', 'FreeWarp', '1턴간 1~4칸 자유이동', 18000, 9000, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(56, 55, 3, 'Normal', '파일럿', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(57, 56, 3, 'Normal', '팬드래건나이트', '이동 D', '1턴간 Move+4', 50, 25, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(58, 57, 3, 'Valuable', '플랑드르', '이동 A', '1턴간 이동 주사위 +2개', 4400, 2200, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(59, 58, 3, 'Normal', '헤럴드깁슨', '이동 B', '2턴간 이동 주사위 +1개', 1510, 755, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(60, 59, 3, 'Normal', '헤이스팅스', '지력 B', '2턴간 Int+3', 2300, 1150, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(61, 60, 3, 'Valuable', '고렘', 'Raider', '이동중에 마주치는 적과 전투', 10500, 5250, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(62, 61, 3, 'Valuable', '아지다하카', '오리발', '2턴간 오리발 사용 가능', 7210, 3605, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(63, 62, 3, 'Normal', '좀비', '짝수저주', '3턴간 짝수 저주', 6800, 3400, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(64, 63, 3, 'Normal', '해골 병사', '홀수저주', '3턴간 홀수 저주', 6800, 3400, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(65, 101, 3, 'Normal', '나탈리', '이동 B', '2턴간 이동 주사위 +1개', 3300, 1650, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(66, 102, 3, 'Normal', '네리샤', '이동 C', '3턴간 Move+4', 1100, 550, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(67, 103, 3, 'Valuable', '데미안', 'Block', '2턴간 방어 주사위 최대값', 23300, 11650, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(68, 104, 3, 'Normal', '디에네', '지력 C', '3턴간 Int+2', 900, 450, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(69, 105, 3, 'Normal', '란', '공격 B', '2턴간 공격 주사위 +1개', 3700, 1850, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(70, 106, 3, 'Normal', '레드헤드', '방어 B', '2턴간 방어 주사위 +1개', 2000, 1000, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(71, 107, 3, 'Normal', '루시엔', '지력 B', '2턴간 Int+3', 2100, 1050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(72, 108, 3, 'Normal', '루크랜서드', '방어 C', '3턴간 Defend+4', 1400, 700, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(73, 109, 3, 'Normal', '리엔', '방어 B', '2턴간 방어 주사위 +1개', 2150, 1075, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(74, 110, 3, 'Valuable', '리차드', '지력 A', '1턴간 Int+4', 2880, 1440, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(75, 111, 3, 'Normal', '마리아', '방어 B', '2턴간 방어 주사위 +1개', 2300, 1150, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(76, 112, 3, 'Valuable', '베라모드', '이동 A', '1턴간 이동 주사위 +2개', 7300, 3650, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(77, 113, 3, 'Valuable', '살라딘2', '순간이동', '1~15칸 사이를 랜덤하게 워프', 28500, 14250, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(78, 114, 3, 'Normal', '손나딘', '방어 B', '2턴간 방어 주사위 +1개', 1850, 925, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(79, 115, 3, 'Normal', '아만딘', '방어 C', '3턴간 Defend+4', 1150, 575, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(80, 116, 3, 'Normal', '아셀라스', '지력 B', '2턴간 Int+3', 1720, 860, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(81, 117, 3, 'Valuable', '아슈레이', '공격 A', '1턴간 공격 주사위 +2개', 8200, 4100, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(82, 118, 3, 'Valuable', '엠블라', '방어 A', '1턴간 방어 주사위 +2개', 5500, 2750, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(83, 119, 3, 'Valuable', '죠안2', '지력 A', '1턴간 Int+4', 6850, 3425, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(84, 120, 3, 'Normal', '쥬디', '공격 B', '2턴간 공격 주사위 +1개', 3800, 1900, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(85, 121, 3, 'Normal', '슈', '이동 C', '3턴간 Move+4', 1600, 800, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(86, 122, 3, 'Valuable', '카를로스', '이동 A', '1턴간 이동 주사위 +2개', 6100, 3050, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(87, 123, 3, 'Valuable', '크리스티앙2', 'Free Warp', '1턴간 1~4칸 자유이동', 20200, 10100, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(88, 124, 3, 'Normal', '프라이오스', '방어 B', '2턴간 방어 주사위 +1개', 9750, 4875, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(89, 125, 3, 'Valuable', '강화병', '자폭', '상대방과 함께 자폭', 5000, 2500, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(90, 126, 3, 'Valuable', '루칼드', '체인지', '2턴간 체인지 사용 가능', 6120, 3060, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(91, 127, 3, 'Valuable', '바룬', '어빌리티 -50', '어빌리티 50% 감소', 6150, 3075, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(92, 128, 3, 'Valuable', '엘더마스터', '자폭', '상대방과 함께 자폭', 6650, 3325, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(93, 129, 3, 'Valuable', '제이슨', '발키리', '2턴간 발키리의 창 사용 가능', 8730, 4365, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(94, 130, 3, 'Valuable', '켄', '아마게돈', '모든 체스맨의 능력치 1/2', 7400, 3700, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(95, 131, 3, 'Valuable', '팬텀 데미안', 'Peace', '3턴간 플레이어와 전투 회피', 28500, 14250, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(96, 132, 3, 'Valuable', '팬텀 마리아', '신의 저주', '저주 타일로 만듬', 22850, 11425, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(97, 133, 3, 'Valuable', '팬텀 유진', '키퍼 C', 'C급 몬스터 소환', 21300, 10650, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(98, 134, 3, 'Valuable', '하이델룬', 'ExWarp', '1턴간 1~6칸 자유이동', 24500, 12250, 100);
REPLACE INTO `tbl_CardInfo` (`f_CID`, `f_Index`, `f_Type`, `f_Rank`, `f_Name`, `f_Skill`, `f_Ability`, `f_BuyPrice`, `f_SellPrice`, `f_Quantity`) VALUES
	(99, 135, 3, 'Valuable', '흑태자', 'GS', '2턴/1턴, 공격/방어 최대값', 250000, 125000, 100);
/*!40000 ALTER TABLE `tbl_CardInfo` ENABLE KEYS */;


-- 테이블 4Leaf.tbl_ItemInfo 구조 내보내기
CREATE TABLE IF NOT EXISTS `tbl_ItemInfo` (
  `f_TID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `f_Index` int(11) unsigned NOT NULL,
  `f_Type` int(11) unsigned NOT NULL,
  `f_Series` varchar(50) COLLATE utf8_bin NOT NULL,
  `f_Name` varchar(50) COLLATE utf8_bin NOT NULL,
  `f_Mount` tinyint(4) unsigned NOT NULL,
  `f_Sex` tinyint(4) unsigned NOT NULL,
  `f_BuyPrice` int(11) unsigned NOT NULL DEFAULT '0',
  `f_SellPrice` int(11) unsigned NOT NULL DEFAULT '0',
  `f_Store` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`f_TID`),
  KEY `ItemIndex` (`f_Index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 테이블 데이터 4Leaf.tbl_ItemInfo:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `tbl_ItemInfo` DISABLE KEYS */;
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(1, 1, 1, 'None', '그림자', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(2, 2, 1, 'None', '남자 몸', 1, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(3, 3, 1, 'None', '여자 몸', 1, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(4, 4, 1, 'None', '레이 몸', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(5, 5, 1, 'None', '마네킨 남', 1, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(6, 6, 1, 'None', '마네킨 여', 1, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(7, 7, 1, 'None', '남자 몸 썬텐', 1, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(8, 8, 1, 'None', '여자 몸 썬텐', 1, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(9, 9, 1, 'None', '레이 몸 썬텐', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(10, 10, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(11, 11, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(12, 12, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(13, 13, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(14, 14, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(15, 15, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(16, 16, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(17, 17, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(18, 18, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(19, 19, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(20, 20, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(21, 21, 1, 'None', '무효 아이템', 1, 0, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(22, 22, 1, 'None', '루시안 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(23, 55, 1, 'None', '조슈아 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(24, 88, 1, 'None', '막시민 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(25, 121, 1, 'None', '보리스 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(26, 154, 1, 'None', '란지에 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(27, 187, 1, 'None', '시벨린 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(28, 220, 1, 'None', '이자크 그냥', 2, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(29, 253, 1, 'None', '이스핀 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(30, 286, 1, 'None', '티치엘 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(31, 319, 1, 'None', '클로에 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(32, 352, 1, 'None', '레이 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(33, 385, 1, 'None', '아나이스 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(34, 418, 1, 'None', '밀라 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(35, 451, 1, 'None', '벤야 그냥', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(36, 483, 1, 'None', '벤야 기타3', 2, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(37, 484, 1, 'Original', '루시안 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(38, 485, 1, 'Original', '조슈아 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(39, 486, 1, 'Original', '막시민 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(40, 487, 1, 'Original', '보리스 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(41, 488, 1, 'Original', '란지에 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(42, 489, 1, 'Original', '시벨린 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(43, 490, 1, 'Original', '이자크 머리', 3, 1, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(44, 491, 1, 'Original', '이스핀 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(45, 492, 1, 'Original', '티치엘 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(46, 493, 1, 'Original', '클로에 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(47, 494, 1, 'Original', '레이 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(48, 495, 1, 'Original', '아나이스 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(49, 496, 1, 'Original', '밀라 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(50, 497, 1, 'Original', '벤야 머리', 3, 2, 30000, 15000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(51, 498, 1, 'None', '교복(동) 와이셔츠', 5, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(52, 499, 1, 'None', '교복(동) 바지', 6, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(53, 500, 1, 'None', '교복(동) 조끼', 5, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(54, 501, 1, 'None', '교복(동) 구두', 7, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(55, 502, 1, 'None', '교복(동) 재킷', 5, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(56, 503, 1, 'None', '교복(동) 블라우스', 5, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(57, 504, 1, 'None', '교복(동) 치마', 6, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(58, 505, 1, 'None', '교복(동) 재킷', 5, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(59, 506, 1, 'None', '교복(동) 양말', 6, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(60, 507, 1, 'None', '교복(동) 구두', 7, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(61, 508, 1, 'None', '교복(동) 조끼', 5, 2, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(62, 509, 1, 'Gray', '드라우프닐 흰수염', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(63, 510, 1, 'Gray', '드라우프닐 옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(64, 511, 1, 'Gray', '드라우프닐 가디건', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(65, 512, 1, 'Gray', '드라우프닐 슬리퍼', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(66, 513, 1, 'Gray', '드라우프닐 지팡이', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(67, 514, 1, 'Gray', '드라우프닐 엘프귀', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(68, 515, 1, 'Gray', '카자 윗도리', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(69, 516, 1, 'Gray', '카자 바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(70, 517, 1, 'Gray', '카자 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(71, 518, 1, 'Gray', '카자 두건', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(72, 519, 1, 'Gray', '카자 팔찌', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(73, 520, 1, 'Gray', '카자 칼', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(74, 521, 1, 'Gray', '카자 손장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(75, 522, 1, 'Gray', '로빈 머리띠', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(76, 523, 1, 'Gray', '로빈 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(77, 524, 1, 'Gray', '로빈 옷', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(78, 525, 1, 'Gray', '로빈 가죽신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(79, 526, 1, 'Gray', '로빈 팔찌', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(80, 527, 1, 'Gray', '로빈 칼', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(81, 528, 1, 'Gray', '기쉬네 로브', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(82, 529, 1, 'Gray', '기쉬네 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(83, 530, 1, 'Gray', '기쉬네 지팡이', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(84, 531, 1, 'Gray', '기쉬네 슬리퍼', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(85, 532, 1, 'Gray', '기쉬네 머리띠', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(86, 533, 1, 'Gray', '흑태자 갑옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(87, 534, 1, 'Gray', '흑태자 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(88, 535, 1, 'Gray', '흑태자 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(89, 536, 1, 'Gray', '흑태자 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(90, 537, 1, 'Gray', '흑태자 투구', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(91, 538, 1, 'WestWind', '시라노 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(92, 539, 1, 'WestWind', '시라노 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(93, 540, 1, 'WestWind', '시라노 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(94, 541, 1, 'WestWind', '시라노 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(95, 542, 1, 'WestWind', '시라노 바지장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(96, 543, 1, 'WestWind', '시라노 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(97, 544, 1, 'WestWind', '카나 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(98, 545, 1, 'WestWind', '카나 윗도리', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(99, 546, 1, 'WestWind', '카나 치마', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(100, 547, 1, 'WestWind', '카나 칼', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(101, 548, 1, 'WestWind', '카나 손목보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(102, 549, 1, 'WestWind', '카나 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(103, 550, 1, 'WestWind', '체사레 모자', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(104, 551, 1, 'WestWind', '체사레 원피스', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(105, 552, 1, 'WestWind', '체사레 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(106, 553, 1, 'WestWind', '체사레 바지', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(107, 554, 1, 'Tempest', '샤른호스트 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(108, 555, 1, 'Tempest', '샤른호스트 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(109, 556, 1, 'Tempest', '샤른호스트 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(110, 557, 1, 'Tempest', '샤른호스트 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(111, 558, 1, 'Tempest', '에밀리오 청룡포', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(112, 559, 1, 'Tempest', '에밀리오 깜장고무신', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(113, 560, 1, 'Tempest', '메리 슈츠', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(114, 561, 1, 'Tempest', '메리 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(115, 562, 1, 'Tempest', '메리 머리장식', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(116, 563, 1, 'Tempest', '메리 채찍', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(117, 564, 1, 'Tempest', '메리 부츠', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(118, 565, 1, 'Tempest', '메리 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(119, 566, 1, 'Tempest', '엘리자베스 분홍드레스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(120, 567, 1, 'Tempest', '엘리자베스 백구두', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(121, 568, 1, 'Tempest', '엘리자베스 흰장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(122, 569, 1, 'Tempest', '엘리자베스 귀걸이', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(123, 570, 1, 'Tempest', '리나 모자', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(124, 571, 1, 'Tempest', '리나 수녀복', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(125, 572, 1, 'Tempest', '리나 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(126, 573, 1, 'Tempest', '리나 안경', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(127, 574, 1, 'Shivan', '사피알딘 터번', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(128, 575, 1, 'Shivan', '사피알딘 제의(내)', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(129, 576, 1, 'Shivan', '사피알딘 제의(외)', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(130, 577, 1, 'Shivan', '사피알딘 구두', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(131, 578, 1, 'Shivan', '사피알딘 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(132, 579, 1, 'Shivan', '얀지슈카 슈츠', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(133, 580, 1, 'Shivan', '얀지슈카 어깨보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(134, 581, 1, 'Shivan', '얀지슈카 타이즈', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(135, 582, 1, 'Shivan', '얀지슈카 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(136, 583, 1, 'Shivan', '얀지슈카 손목보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(137, 584, 1, 'Shivan', '알아샤 윗도리', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(138, 585, 1, 'Shivan', '알아샤 쫄바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(139, 586, 1, 'Shivan', '알아샤 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(140, 587, 1, 'Shivan', '알아샤 손목보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(141, 588, 1, 'Crimson', '롤랑 티셔츠', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(142, 589, 1, 'Crimson', '롤랑 반바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(143, 590, 1, 'Crimson', '롤랑 구두', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(144, 591, 1, 'Crimson', '롤랑 머플러', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(145, 592, 1, 'Crimson', '롤랑 팔장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(146, 593, 1, 'Crimson', '롤랑 양말', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(147, 594, 1, 'Crimson', '버몬트 재킷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(148, 595, 1, 'Crimson', '버몬트 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(149, 596, 1, 'Crimson', '버몬트 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(150, 597, 1, 'Crimson', '버몬트 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(151, 598, 1, 'Crimson', '엘핀스톤 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(152, 599, 1, 'Crimson', '엘핀스톤 치마', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(153, 600, 1, 'Crimson', '엘핀스톤 조끼', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(154, 601, 1, 'Crimson', '엘핀스톤 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(155, 602, 1, 'Crimson', '엘핀스톤 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(156, 603, 1, 'Crimson', '엘핀스톤 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(157, 604, 1, 'Crimson', '엘핀스톤 머플러', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(158, 605, 1, 'Crimson', '바이올라 블라우스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(159, 606, 1, 'Crimson', '바이올라 치마', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(160, 607, 1, 'Crimson', '바이올라 타이즈', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(161, 608, 1, 'Crimson', '바이올라 루즈박스', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(162, 609, 1, 'Crimson', '바이올라 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(163, 610, 1, 'Crimson', '바이올라 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(164, 611, 1, 'Crimson', '바이올라 구두', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(165, 612, 1, 'Apocalyse', '크리스티앙 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(166, 613, 1, 'Apocalyse', '크리스티앙 코드', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(167, 614, 1, 'Apocalyse', '크리스티앙 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(168, 615, 1, 'Apocalyse', '크리스티나 모자', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(169, 616, 1, 'Apocalyse', '크리스티나 블라우스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(170, 617, 1, 'Apocalyse', '크리스티나 치마', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(171, 618, 1, 'Apocalyse', '크리스티나 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(172, 619, 1, 'Apocalyse', '크리스티나 귀걸이', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(173, 620, 1, 'Apocalyse', '크리스티나 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(174, 621, 1, 'Apocalyse', '크리스티나 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(175, 622, 1, 'Apocalyse', '알바티니 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(176, 623, 1, 'Apocalyse', '알바티니 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(177, 624, 1, 'Apocalyse', '알바티니 스커트', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(178, 625, 1, 'Apocalyse', '알바티니 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(179, 626, 1, 'Apocalyse', '알바티니 어깨보호대', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(180, 627, 1, 'Apocalyse', '알바티니 손목보호대', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(181, 628, 1, 'Apocalyse', '철가면 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(182, 629, 1, 'Apocalyse', '철가면 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(183, 630, 1, 'Apocalyse', '철가면 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(184, 631, 1, 'Apocalyse', '철가면 조끼', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(185, 632, 1, 'Apocalyse', '철가면 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(186, 633, 1, 'Apocalyse', '철가면 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(187, 634, 1, 'Apocalyse', '철가면 허리띠', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(188, 635, 1, 'Fantasy', '전사 쫄티(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(189, 636, 1, 'Fantasy', '전사 팔찌(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(190, 637, 1, 'Fantasy', '전사 바지(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(191, 638, 1, 'Fantasy', '전사 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(192, 639, 1, 'Fantasy', '전사 머플러(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(193, 640, 1, 'Fantasy', '전사 쫄티(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(194, 641, 1, 'Fantasy', '전사 팔찌(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(195, 642, 1, 'Fantasy', '전사 바지(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(196, 643, 1, 'Fantasy', '전사 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(197, 644, 1, 'Fantasy', '전사 팔찌(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(198, 645, 1, 'Fantasy', '마법사 모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(199, 646, 1, 'Fantasy', '마법사 윗도리(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(200, 647, 1, 'Fantasy', '마법사 바지(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(201, 648, 1, 'Fantasy', '마법사 외투(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(202, 649, 1, 'Fantasy', '마법사 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(203, 650, 1, 'Fantasy', '마법사 손목보호대(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(204, 651, 1, 'Fantasy', '마법사 모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(205, 652, 1, 'Fantasy', '마법사 외투(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(206, 653, 1, 'Fantasy', '마법사 반바지(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(207, 654, 1, 'Fantasy', '마법사 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(208, 655, 1, 'Fantasy', '마법사 손목보호대(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(209, 656, 1, 'Fantasy', '사냥꾼 모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(210, 657, 1, 'Fantasy', '사냥꾼 외투(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(211, 658, 1, 'Fantasy', '사냥꾼 윗도리(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(212, 659, 1, 'Fantasy', '사냥꾼 바지(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(213, 660, 1, 'Fantasy', '사냥꾼 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(214, 661, 1, 'Fantasy', '사냥꾼 장갑(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(215, 662, 1, 'Fantasy', '사냥꾼 활과 활통(남)', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(216, 663, 1, 'Fantasy', '사냥꾼 모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(217, 664, 1, 'Fantasy', '사냥꾼 외투(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(218, 665, 1, 'Fantasy', '사냥꾼 치마(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(219, 666, 1, 'Fantasy', '사냥꾼 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(220, 667, 1, 'Fantasy', '사냥꾼 장갑(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(221, 668, 1, 'Fantasy', '사냥꾼 활과 활통(여)', 8, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(222, 669, 1, 'Fantasy', '수도사 수도복(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(223, 670, 1, 'Fantasy', '수도사 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(224, 671, 1, 'Fantasy', '수도사 수도복(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(225, 672, 1, 'Fantasy', '수도사 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(226, 673, 1, 'Fantasy', '근위기사 목티(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(227, 674, 1, 'Fantasy', '근위기사 롱코트(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(228, 675, 1, 'Fantasy', '근위기사 장갑(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(229, 676, 1, 'Fantasy', '근위기사 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(230, 677, 1, 'Fantasy', '근위기사 목티(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(231, 678, 1, 'Fantasy', '근위기사 롱코트(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(232, 679, 1, 'Fantasy', '근위기사 장갑(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(233, 680, 1, 'Fantasy', '근위기사 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(234, 681, 1, 'Morden', '흰괭이 모자', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(235, 682, 1, 'Morden', '흰괭이 마스크', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(236, 683, 1, 'Morden', '흰괭이 장갑', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(237, 684, 1, 'Morden', '흰괭이 원피스', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(238, 685, 1, 'Morden', '흰괭이 신발', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(239, 686, 1, 'Apocalyse', '철가면 가면', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(240, 687, 1, 'Gray', 'GS 갑옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(241, 688, 1, 'Gray', 'GS 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(242, 689, 1, 'Gray', 'GS 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(243, 690, 1, 'Gray', 'GS 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(244, 691, 1, 'Gray', 'GS 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(245, 692, 1, 'Gray', 'GS 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(246, 693, 1, 'WestWind', '메디치 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(247, 694, 1, 'WestWind', '메디치 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(248, 695, 1, 'WestWind', '메디치 바지장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(249, 696, 1, 'WestWind', '메디치 갑옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(250, 697, 1, 'WestWind', '메디치 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(251, 698, 1, 'WestWind', '메디치 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(252, 699, 1, 'WestWind', '메디치 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(253, 700, 1, 'WestWind', '메르세데스 드레스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(254, 701, 1, 'WestWind', '메르세데스 숄', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(255, 702, 1, 'WestWind', '괴도샤른 모자', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(256, 703, 1, 'WestWind', '괴도샤른 가면', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(257, 704, 1, 'WestWind', '괴도샤른 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(258, 705, 1, 'WestWind', '괴도샤른 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(259, 706, 1, 'WestWind', '괴도샤른 윗도리', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(260, 707, 1, 'WestWind', '괴도샤른 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(261, 708, 1, 'WestWind', '괴도샤른 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(262, 709, 1, 'Tempest', '제인쇼어 검은드레스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(263, 710, 1, 'Tempest', '제인쇼어 깃털장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(264, 711, 1, 'Tempest', '제인쇼어 검은구두', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(265, 712, 1, 'Tempest', '제인쇼어 담뱃대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(266, 713, 1, 'Tempest', '제인쇼어 검은장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(267, 714, 1, 'Tempest', '오필리아 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(268, 715, 1, 'Tempest', '오필리아 원피스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(269, 716, 1, 'Tempest', '오필리아 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(270, 717, 1, 'Tempest', '오필리아 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(271, 718, 1, 'Tempest', '코델리아 원피스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(272, 719, 1, 'Tempest', '코델리아 구두', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(273, 720, 1, 'Tempest', '코델리아 가방', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(274, 721, 1, 'Shivan', '무카파 스커트', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(275, 722, 1, 'Shivan', '무카파 바지장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(276, 723, 1, 'Shivan', '무카파 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(277, 724, 1, 'Shivan', '무카파 근육옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(278, 725, 1, 'Shivan', '마르자나 슈트', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(279, 726, 1, 'Shivan', '마르자나 양말', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(280, 727, 1, 'Shivan', '마르자나 토시', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(281, 728, 1, 'Shivan', '마르자나 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(282, 729, 1, 'Shivan', '마르자나 팔장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(283, 730, 1, 'Shivan', '마르자나 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(284, 731, 1, 'Shivan', '마르자나 시미터', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(285, 732, 1, 'Apocalyse', '죠안 귀걸이', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(286, 733, 1, 'Apocalyse', '죠안 빨간구두', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(287, 734, 1, 'Apocalyse', '죠안 빨간드레스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(288, 735, 1, 'Apocalyse', '죠안 빨간장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(289, 736, 1, 'Apocalyse', '죠안 스타킹', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(290, 737, 1, 'Apocalyse', '죠안 검L Type-l', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(291, 738, 1, 'Apocalyse', '죠안 왕리본', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(292, 739, 1, 'Fantasy', '엘프 귀', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(293, 740, 1, 'Tempest', '샤른호스트 살색쫄티', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(294, 741, 1, 'Shivan', '아기다하카(남) 깃털옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(295, 742, 1, 'Shivan', '아기다하카(남) 발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(296, 743, 1, 'Shivan', '아기다하카(여) 깃털옷', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(297, 744, 1, 'Shivan', '아기다하카(여) 발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(298, 745, 1, 'Shivan', '아기다하카(남) 가죽옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(299, 746, 1, 'Shivan', '아기다하카(남) 발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(300, 747, 1, 'Shivan', '아기다하카(여) 가죽옷', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(301, 748, 1, 'Shivan', '아기다하카(여) 발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(302, 749, 1, 'Accessories', '여자애 인형(남)', 9, 1, 5000, 2500, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(303, 750, 1, 'Accessories', '여자애 인형(여)', 9, 2, 5000, 2500, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(304, 751, 1, 'Gray', '라시드 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(305, 752, 1, 'Gray', '라시드 검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(306, 753, 1, 'Gray', '라시드 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(307, 754, 1, 'Gray', '라시드 갑옷', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(308, 755, 1, 'Gray', '라시드 팔찌', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(309, 756, 1, 'Gray', '라시드 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(310, 757, 1, 'Gray', '이올린 머리띠', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(311, 758, 1, 'Gray', '이올린 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(312, 759, 1, 'Gray', '이올린 갑옷(하의)', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(313, 760, 1, 'Gray', '이올린 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(314, 761, 1, 'Gray', '이올린 바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(315, 762, 1, 'Gray', '이올린 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(316, 763, 1, 'Gray', '이올린 갑옷(상의)', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(317, 764, 1, 'Tempest', '클라우제비츠 머리띠', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(318, 765, 1, 'Tempest', '클라우제비츠 어깨장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(319, 766, 1, 'Tempest', '클라우제비츠 부츠', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(320, 767, 1, 'Tempest', '클라우제비츠 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(321, 768, 1, 'Tempest', '클라우제비츠 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(322, 769, 1, 'Tempest', '클라우제비츠 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(323, 770, 1, 'Tempest', '클라우제비츠 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(324, 771, 1, 'Tempest', '앤 부츠', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(325, 772, 1, 'Tempest', '앤 제복 상의', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(326, 773, 1, 'Tempest', '앤 제복 바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(327, 774, 1, 'Tempest', '앤 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(328, 775, 1, 'Tempest', '앤 권총', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(329, 776, 1, 'Shivan', '살라딘 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(330, 777, 1, 'Shivan', '살라딘 두건', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(331, 778, 1, 'Shivan', '살라딘 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(332, 779, 1, 'Shivan', '살라딘 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(333, 780, 1, 'Shivan', '살라딘 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(334, 781, 1, 'Shivan', '살라딘 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(335, 782, 1, 'Shivan', '살라딘 팔찌', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(336, 783, 1, 'Shivan', '셰라자드 원피스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(337, 784, 1, 'Shivan', '셰라자드 외투', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(338, 785, 1, 'Shivan', '셰라자드 팔찌', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(339, 786, 1, 'Shivan', '오스만 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(340, 787, 1, 'Shivan', '오스만 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(341, 788, 1, 'Shivan', '오스만 어깨장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(342, 789, 1, 'Shivan', '오스만 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(343, 790, 1, 'Shivan', '오스만 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(344, 791, 1, 'Shivan', '아두스베이 복면', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(345, 792, 1, 'Shivan', '아두스베이 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(346, 793, 1, 'Shivan', '아두스베이 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(347, 794, 1, 'Shivan', '아두스베이 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(348, 795, 1, 'Shivan', '아두스베이 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(349, 796, 1, 'Shivan', '아두스베이 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(350, 797, 1, 'Shivan', '아두스베이 단도', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(351, 798, 1, 'Crimson', '아델라이데 머리띠', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(352, 799, 1, 'Crimson', '아델라이데 드레스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(353, 800, 1, 'Crimson', '아델라이데 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(354, 801, 1, 'Apocalyse', '시안 수염', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(355, 802, 1, 'Apocalyse', '시안 지팡이', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(356, 803, 1, 'Apocalyse', '시안 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(357, 804, 1, 'Apocalyse', '시안 로브', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(358, 805, 1, 'Gray', '신비의전대(남) 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(359, 806, 1, 'Gray', '신비의전대(남) 마스크', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(360, 807, 1, 'Gray', '신비의전대(남) 투구', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(361, 808, 1, 'Gray', '신비의전대(여) 망토', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(362, 809, 1, 'Gray', '신비의전대(여) 마스크', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(363, 810, 1, 'Gray', '신비의전대(여) 투구', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(364, 811, 1, 'Crimson', '버몬트 바리사다', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(365, 812, 1, 'Tempest', '오필리아 마법사 지팡이', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(366, 813, 1, 'Apocalyse', '알바티니 검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(367, 814, 1, 'Apocalyse', '크리스티앙 리볼버', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(368, 815, 1, 'Gray', '흑태자 아수라검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(369, 816, 1, 'Original', '루시안 외투', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(370, 817, 1, 'Original', '루시안 부츠', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(371, 818, 1, 'Original', '루시안 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(372, 819, 1, 'Original', '루시안 장갑', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(373, 820, 1, 'Original', '루시안 상의', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(374, 821, 1, 'Original', '조슈아 구두', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(375, 822, 1, 'Original', '조슈아 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(376, 823, 1, 'Original', '조슈아 셔츠', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(377, 824, 1, 'Original', '조슈아 점퍼', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(378, 825, 1, 'Original', '막시민 외투', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(379, 826, 1, 'Original', '막시민 구두', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(380, 827, 1, 'Original', '막시민 셔츠', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(381, 828, 1, 'Original', '막시민 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(382, 829, 1, 'Original', '막시민 안경', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(383, 830, 1, 'Original', '보리스 망토', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(384, 831, 1, 'Original', '보리스 상의', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(385, 832, 1, 'Original', '보리스 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(386, 833, 1, 'Original', '보리스 장갑', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(387, 834, 1, 'Original', '보리스 구두', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(388, 835, 1, 'Original', '란지에 구두', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(389, 836, 1, 'Original', '란지에 조끼', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(390, 837, 1, 'Original', '란지에 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(391, 838, 1, 'Original', '란지에 셔츠', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(392, 839, 1, 'Original', '란지에 외투', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(393, 840, 1, 'Original', '시벨린 부츠', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(394, 841, 1, 'Original', '시벨린 상의', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(395, 842, 1, 'Original', '시벨린 장갑', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(396, 843, 1, 'Original', '시벨린 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(397, 844, 1, 'Original', '이자크 고무신', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(398, 845, 1, 'Original', '이자크 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(399, 846, 1, 'Original', '이자크 상의', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(400, 847, 1, 'Original', '이자크 팔찌', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(401, 848, 1, 'Original', '이스핀 모자', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(402, 849, 1, 'Original', '이스핀 긴양말', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(403, 850, 1, 'Original', '이스핀 반바지', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(404, 851, 1, 'Original', '이스핀 상의', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(405, 852, 1, 'Original', '이스핀 조끼', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(406, 853, 1, 'Original', '이스핀 팔지', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(407, 854, 1, 'Original', '이스핀 구두', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(408, 855, 1, 'Original', '티치엘 흰양말', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(409, 856, 1, 'Original', '티치엘 구두', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(410, 857, 1, 'Original', '티치엘 원피스', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(411, 858, 1, 'Original', '클로에 드레스', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(412, 859, 1, 'Original', '클로에 머리띠', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(413, 860, 1, 'Original', '레이 두건', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(414, 861, 1, 'Original', '레이 외투', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(415, 862, 1, 'Original', '레이 슈츠', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(416, 863, 1, 'Original', '레이 팔토시', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(417, 864, 1, 'Original', '레이 신발', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(418, 865, 1, 'Original', '아나이스 외투', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(419, 866, 1, 'Original', '아나이스 리본', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(420, 867, 1, 'Original', '아나이스 신발', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(421, 868, 1, 'Original', '아나이스 원피스', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(422, 869, 1, 'Original', '밀라 롱부츠', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(423, 870, 1, 'Original', '밀라 해골귀걸이', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(424, 871, 1, 'Original', '밀라 해골티', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(425, 872, 1, 'Original', '밀라 반바지', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(426, 873, 1, 'Original', '밀라 바지장식', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(427, 874, 1, 'Original', '밀라 팔토시', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(428, 875, 1, 'Original', '벤야 잠옷', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(429, 876, 1, 'Morden', '한조 복면', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(430, 877, 1, 'Morden', '한조 붉은머플러', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(431, 878, 1, 'Morden', '한조 신발', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(432, 879, 1, 'Morden', '한조 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(433, 880, 1, 'Morden', '한조 그물옷', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(434, 881, 1, 'Morden', '한조 장갑', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(435, 882, 1, 'Morden', '한복 저고리(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(436, 883, 1, 'Morden', '한복 바지(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(437, 884, 1, 'Morden', '한복 조끼(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(438, 885, 1, 'Morden', '한복 고무신(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(439, 886, 1, 'Morden', '한복 노랑저고리(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(440, 887, 1, 'Morden', '한복 빨강치마(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(441, 888, 1, 'Morden', '한복 버선(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(442, 889, 1, 'Morden', '한복 고무신(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(443, 890, 1, 'Morden', '에스키모 방한복(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(444, 891, 1, 'Morden', '에스키모 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(445, 892, 1, 'Morden', '에스키모 방한복(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(446, 893, 1, 'Morden', '에스키모 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(447, 894, 1, 'Morden', '산타 빨간모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(448, 895, 1, 'Morden', '산타 수염(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(449, 896, 1, 'Morden', '산타 빨간외투(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(450, 897, 1, 'Morden', '산타 빨간장갑(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(451, 898, 1, 'Morden', '산타 선물보따리(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(452, 899, 1, 'Morden', '산타 장화(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(453, 900, 1, 'Morden', '산타 빨간모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(454, 901, 1, 'Morden', '산타 수염(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(455, 902, 1, 'Morden', '산타 빨간외투(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(456, 903, 1, 'Morden', '산타 빨간장갑(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(457, 904, 1, 'Morden', '산타 선물보따리(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(458, 905, 1, 'Morden', '산타 빨간바지(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(459, 906, 1, 'Morden', '산타 장화(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(460, 907, 1, 'Morden', '루돌프 모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(461, 908, 1, 'Morden', '루돌프 빨간코(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(462, 909, 1, 'Morden', '루돌프 방울(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(463, 910, 1, 'Morden', '루돌프 털옷(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(464, 911, 1, 'Morden', '루돌프 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(465, 912, 1, 'Morden', '루돌프 모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(466, 913, 1, 'Morden', '루돌프 빨간코(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(467, 914, 1, 'Morden', '루돌프 방울(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(468, 915, 1, 'Morden', '루돌프 털옷(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(469, 916, 1, 'Morden', '루돌프 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(470, 917, 1, 'Morden', '눈사람 눈송이외투(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(471, 918, 1, 'Morden', '눈사람 당근코(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(472, 919, 1, 'Morden', '눈사람 눈송이외투(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(473, 920, 1, 'Morden', '눈사람 당근코(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(474, 921, 1, 'Accessories', '하얀깃털날개(남)', 9, 1, 2850, 1425, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(475, 922, 1, 'Accessories', '하얀깃털날개(여)', 9, 2, 2850, 1425, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(476, 923, 1, 'Accessories', '검은깃털날개(남)', 9, 1, 2850, 1425, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(477, 924, 1, 'Accessories', '검은깃털날개(여)', 9, 2, 2850, 1425, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(478, 925, 1, 'G3P2', '살라딘II 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(479, 926, 1, 'G3P2', '살라딘II 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(480, 927, 1, 'G3P2', '살라딘II 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(481, 928, 1, 'G3P2', '살라딘II 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(482, 929, 1, 'G3P2', '살라딘II 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(483, 930, 1, 'G3P2', '살라딘II B슬라이서', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(484, 931, 1, 'G3P2', '죠안II 모자', 4, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(485, 932, 1, 'G3P2', '죠안II 상의', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(486, 933, 1, 'G3P2', '죠안II 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(487, 934, 1, 'G3P2', '죠안II 치마', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(488, 935, 1, 'G3P2', '죠안II 치마 덧옷', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(489, 936, 1, 'G3P2', '죠안II 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(490, 937, 1, 'G3P2', '죠안II 검', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(491, 938, 1, 'G3P2', '베라모드(남) 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(492, 939, 1, 'G3P2', '베라모드(남) 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(493, 940, 1, 'G3P2', '베라모드(남) 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(494, 941, 1, 'G3P2', '베라모드(남) 허리장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(495, 942, 1, 'G3P2', '베라모드(남) 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(496, 943, 1, 'G3P2', '베라모드(여) 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(497, 944, 1, 'G3P2', '베라모드(여) 바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(498, 945, 1, 'G3P2', '베라모드(여) 외투', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(499, 946, 1, 'G3P2', '베라모드(여) 허리장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(500, 947, 1, 'G3P2', '베라모드(여) 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(501, 948, 1, 'G3P2', '란 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(502, 949, 1, 'G3P2', '란 검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(503, 950, 1, 'G3P2', '란 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(504, 951, 1, 'G3P2', '란 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(505, 952, 1, 'G3P2', '란 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(506, 953, 1, 'G3P2', '루시엔 플레어스커트', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(507, 954, 1, 'G3P2', '루시엔 니삭스', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(508, 955, 1, 'G3P2', '루시엔 터틀넥티', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(509, 956, 1, 'G3P2', '루시엔 스트랩슈즈', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(510, 957, 1, 'G3P2', '루시엔 사진기가방', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(511, 958, 1, 'G3P2', '루시엔 손목보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(512, 959, 1, 'G3P2', '크리스티앙II 쫄티', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(513, 960, 1, 'G3P2', '크리스티앙II 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(514, 961, 1, 'G3P2', '크리스티앙II 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(515, 962, 1, 'G3P2', '크리스티앙II 허리띠', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(516, 963, 1, 'G3P2', '크리스티앙II 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(517, 964, 1, 'Crimson', '올리비에 니삭스', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(518, 965, 1, 'Crimson', '올리비에 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(519, 966, 1, 'Crimson', '올리비에 상의', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(520, 967, 1, 'Crimson', '올리비에 하의', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(521, 968, 1, 'Crimson', '올리비에 외투', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(522, 969, 1, 'Crimson', '올리비에 손목보호대', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(523, 970, 1, 'Crimson', '올리비에 귀걸이', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(524, 971, 1, 'Crimson', '벨제부르 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(525, 972, 1, 'Crimson', '벨제부르 투구', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(526, 973, 1, 'Crimson', '벨제부르 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(527, 974, 1, 'Crimson', '벨제부르 갑주(상)', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(528, 975, 1, 'Crimson', '벨제부르 마스크', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(529, 976, 1, 'Crimson', '벨제부르 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(530, 977, 1, 'Crimson', '벨제부르 갑주(하)', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(531, 978, 1, 'Shivan', '발라 머리띠', 4, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(532, 979, 1, 'Shivan', '발라 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(533, 980, 1, 'Shivan', '발라 허리띠', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(534, 981, 1, 'Shivan', '발라 스커트', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(535, 982, 1, 'Shivan', '발라 시미터', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(536, 983, 1, 'Shivan', '발라 마스크', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(537, 984, 1, 'Shivan', '발라 쫄티', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(538, 985, 1, 'Shivan', '발라 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(539, 986, 1, 'Accessories', '4LEAF 귀걸이 블루(여)', 9, 2, 8000, 4000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(540, 987, 1, 'Accessories', '4LEAF 귀걸이 블루(남)', 9, 1, 8000, 4000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(541, 988, 1, 'Apocalyse', '버몬트 가발', 3, 1, 20000, 10000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(542, 989, 1, 'Gray', '드라우프닐 가발', 3, 1, 3700, 1850, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(543, 990, 1, 'WestWind', '시라노 가발', 3, 1, 15000, 7500, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(544, 991, 1, 'Shivan', '살라딘 가발', 3, 1, 20000, 10000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(545, 992, 1, 'Tempest', '샤른호스트 가발', 3, 1, 13500, 6750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(546, 993, 1, 'Tempest', '클라우제비츠 가발', 3, 1, 22000, 11000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(547, 994, 1, 'Shivan', '얀지슈카 가발', 3, 2, 7000, 3500, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(548, 995, 1, 'Tempest', '리나 가발', 3, 2, 3500, 1750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(549, 996, 1, 'Tempest', '메리 가발', 3, 2, 17000, 8500, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(550, 997, 1, 'Gray', '로빈 가발', 3, 2, 3200, 1600, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(551, 998, 1, 'Tempest', '오필리아 가발', 3, 2, 5100, 2550, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(552, 999, 1, 'WestWind', '메르세데스 가발', 3, 2, 4550, 2275, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(553, 1000, 1, 'Shivan', '셰라자드 가발', 3, 2, 13500, 6750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(554, 1001, 1, 'Tempest', '에밀리오 가발', 3, 1, 10000, 5000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(555, 1002, 1, 'Accessories', '4LEAF 귀걸이 그린(여)', 9, 2, 8000, 4000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(556, 1003, 1, 'Accessories', '4LEAF 귀걸이 그린(남)', 9, 1, 8000, 4000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(557, 1004, 1, 'None', '교복(하) 와이셔츠', 5, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(558, 1005, 1, 'None', '교복(하) 반바지', 6, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(559, 1006, 1, 'None', '교복(하) 신발', 7, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(560, 1007, 1, 'None', '교복(하) 블라우스', 5, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(561, 1008, 1, 'None', '교복(하) 치마', 6, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(562, 1009, 1, 'None', '교복(하) 신발', 7, 1, 0, 0, 'None');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(563, 1010, 1, 'Sport', '물안경(남)', 4, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(564, 1011, 1, 'Sport', '튜브(남)', 9, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(565, 1012, 1, 'Sport', '오리발(남)', 7, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(566, 1013, 1, 'Sport', '물안경(여)', 4, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(567, 1014, 1, 'Sport', '튜브(여)', 9, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(568, 1015, 1, 'Sport', '오리발(여)', 7, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(569, 1016, 1, 'Life', '여름남방(남)', 5, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(570, 1017, 1, 'Life', '여름남방(여)', 5, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(571, 1018, 1, 'Life', '포리프면티(남)', 5, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(572, 1019, 1, 'Life', '포리프면티(여)', 5, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(573, 1020, 1, 'Sport', '수영복바지(남)', 6, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(574, 1021, 1, 'Sport', '수영복(여)', 5, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(575, 1022, 1, 'Life', '민소매티(남)', 5, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(576, 1023, 1, 'Life', '민소매티(여)', 5, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(577, 1024, 1, 'Life', '청반바지(남)', 6, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(578, 1025, 1, 'Life', '청반바지(여)', 6, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(579, 1026, 1, 'Accessories', '선그라스(남)', 9, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(580, 1027, 1, 'Life', '여름슬리퍼(남)', 7, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(581, 1028, 1, 'Accessories', '선그라스(여)', 9, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(582, 1029, 1, 'Life', '여름슬리퍼(여)', 7, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(583, 1030, 1, 'Sport', '스포츠백(남)', 9, 1, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(584, 1031, 1, 'Sport', '스포츠백(여)', 9, 2, 250, 125, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(585, 1032, 1, 'Morden', '경찰 모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(586, 1033, 1, 'Morden', '경찰 제복남방(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(587, 1034, 1, 'Morden', '경찰 제복바지(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(588, 1035, 1, 'Morden', '경찰 제복구두(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(589, 1036, 1, 'Morden', '경찰 모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(590, 1037, 1, 'Morden', '경찰 제복남방(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(591, 1038, 1, 'Morden', '경찰 제복바지(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(592, 1039, 1, 'Morden', '경찰 제복구두(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(593, 1040, 1, 'Morden', '군인 철모(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(594, 1041, 1, 'Morden', '군인 군복상의(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(595, 1042, 1, 'Morden', '군인 군복하의(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(596, 1043, 1, 'Morden', '군인 군용멜빵(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(597, 1044, 1, 'Morden', '군인 군화(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(598, 1045, 1, 'Morden', '군인 철모(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(599, 1046, 1, 'Morden', '군인 군복상의(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(600, 1047, 1, 'Morden', '군인 군복하의(여)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(601, 1048, 1, 'Morden', '군인 군복멜빵(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(602, 1049, 1, 'Morden', '군인 군화(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(603, 1050, 1, 'Morden', '경찰 방독면(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(604, 1051, 1, 'Morden', '군인 K2소총(남)', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(605, 1052, 1, 'Morden', '군인 모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(606, 1053, 1, 'Morden', '경찰 방탄조끼(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(607, 1054, 1, 'Morden', '경찰 방독면(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(608, 1055, 1, 'Morden', '군인 K2소총(여)', 8, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(609, 1056, 1, 'Morden', '군인 모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(610, 1057, 1, 'Morden', '경찰 방탄조끼(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(611, 1058, 1, 'Morden', '뺑덕어멈 저고리', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(612, 1059, 1, 'Morden', '뺑덕어멈 치마', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(613, 1060, 1, 'Morden', '뺑덕어멈 곰방대', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(614, 1061, 1, 'Morden', '민속의상 고무신', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(615, 1062, 1, 'Morden', '상궁 당의', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(616, 1063, 1, 'Morden', '상궁 치마', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(617, 1064, 1, 'Morden', '중전 당의', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(618, 1065, 1, 'Morden', '중전 치마', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(619, 1066, 1, 'Morden', '임금 면류관', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(620, 1067, 1, 'Morden', '임금 황룡포', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(621, 1068, 1, 'Morden', '민속의상 신발', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(622, 1069, 1, 'Morden', '대감 저고리', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(623, 1070, 1, 'Morden', '대감 바지', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(624, 1071, 1, 'Morden', '대감 관모', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(625, 1072, 1, 'Morden', '대감 관복(청)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(626, 1073, 1, 'Morden', '포도대장 모자', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(627, 1074, 1, 'Morden', '포도대장 도포', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(628, 1075, 1, 'Morden', '포도대장 지휘채', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(629, 1076, 1, 'Morden', '중전 가발', 3, 2, 2000, 1000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(630, 1077, 1, 'Morden', '상궁 가발', 3, 2, 1500, 750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(631, 1078, 1, 'G3P2', '데미안 폴라민소매티', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(632, 1079, 1, 'G3P2', '데미안 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(633, 1080, 1, 'G3P2', '데미안 겉치마', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(634, 1081, 1, 'G3P2', '데미안 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(635, 1082, 1, 'G3P2', '데미안 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(636, 1083, 1, 'G3P2', '데미안 목장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(637, 1084, 1, 'G3P2', '데미안 십자목걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(638, 1085, 1, 'G3P2', '데미안 멸살지옥검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(639, 1086, 1, 'G3P2', '네리사 상의', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(640, 1087, 1, 'G3P2', '네리사 치마', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(641, 1088, 1, 'G3P2', '네리사 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(642, 1089, 1, 'G3P2', '네리사 리본', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(643, 1090, 1, 'G3P2', '네리사 밍밍인형', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(644, 1091, 1, 'G3P2', '카를로스 구룡포', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(645, 1092, 1, 'G3P2', '카를로스 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(646, 1093, 1, 'G3P2', '카를로스 겉치마', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(647, 1094, 1, 'G3P2', '카를로스 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(648, 1095, 1, 'G3P2', '카를로스 팔찌', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(649, 1096, 1, 'G3P2', '카를로스 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(650, 1097, 1, 'G3P2', '카를로스 더블시더', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(651, 1098, 1, 'G3P2', '리엔 차이나드레스N', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(652, 1099, 1, 'G3P2', '리엔 손목장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(653, 1100, 1, 'G3P2', '리엔 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(654, 1101, 1, 'G3P2', '리엔 요리칼', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(655, 1102, 1, 'Morden', '대감 관복(적)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(656, 1103, 1, 'Shivan', '살라딘 시미터', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(657, 1104, 1, 'Accessories', '칼린츠 인형(남)', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(658, 1105, 1, 'Accessories', '아도라 인형(남)', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(659, 1106, 1, 'Accessories', '칼린츠 인형(여)', 9, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(660, 1107, 1, 'Accessories', '아도라 인형(여)', 9, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(661, 1108, 1, 'Magnacarta', '칼린츠 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(662, 1109, 1, 'Magnacarta', '칼린츠 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(663, 1110, 1, 'Magnacarta', '칼린츠 외투', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(664, 1111, 1, 'Magnacarta', '칼린츠 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(665, 1112, 1, 'Magnacarta', '칼린츠 손목장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(666, 1113, 1, 'Magnacarta', '칼린츠 허리장식', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(667, 1114, 1, 'Magnacarta', '칼린츠 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(668, 1115, 1, 'Magnacarta', '칼린츠 버선', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(669, 1116, 1, 'Magnacarta', '칼린츠 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(670, 1117, 1, 'Magnacarta', '칼린츠 목걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(671, 1118, 1, 'Magnacarta', '칼린츠 소울블레이드L', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(672, 1119, 1, 'Magnacarta', '페르난 상의', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(673, 1120, 1, 'Magnacarta', '페르난 하의', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(674, 1121, 1, 'Magnacarta', '페르난 가슴보호대', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(675, 1122, 1, 'Magnacarta', '페르난 어깨보호대', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(676, 1123, 1, 'Magnacarta', '페르난 허리보호대', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(677, 1124, 1, 'Magnacarta', '페르난 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(678, 1125, 1, 'Magnacarta', '페르난 손목보호대', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(679, 1126, 1, 'Magnacarta', '페르난 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(680, 1127, 1, 'Magnacarta', '페르난 망토', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(681, 1128, 1, 'Magnacarta', '페르난 참철검', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(682, 1129, 1, 'Magnacarta', '로프마 머슬보디', 5, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(683, 1130, 1, 'Magnacarta', '로프마 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(684, 1131, 1, 'Magnacarta', '로프마 장갑', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(685, 1132, 1, 'Magnacarta', '로프마 신발', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(686, 1133, 1, 'Magnacarta', '로프마 귀걸이', 9, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(687, 1134, 1, 'Magnacarta', '로프마 핸드캐논', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(688, 1135, 1, 'Magnacarta', '아도라 상의(노랑)', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(689, 1136, 1, 'Magnacarta', '아도라 상의(주황)', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(690, 1137, 1, 'Magnacarta', '아도라 치마(노랑)', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(691, 1138, 1, 'Magnacarta', '아도라 치마(주황)', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(692, 1139, 1, 'Magnacarta', '아도라 목장식(노랑)', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(693, 1140, 1, 'Magnacarta', '아도라 목장식(주황)', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(694, 1141, 1, 'Magnacarta', '아도라 손목장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(695, 1142, 1, 'Magnacarta', '아도라 한쪽타이즈', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(696, 1143, 1, 'Magnacarta', '아도라 신발(노랑)', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(697, 1144, 1, 'Magnacarta', '아도라 신발(주황)', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(698, 1145, 1, 'Magnacarta', '아도라 소울블레이드', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(699, 1146, 1, 'Magnacarta', '쥬클레시아 원피스', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(700, 1147, 1, 'Magnacarta', '쥬클레시아 손목장식', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(701, 1148, 1, 'Magnacarta', '쥬클레시아 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(702, 1149, 1, 'Magnacarta', '쥬클레시아 노리개', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(703, 1150, 1, 'Magnacarta', '첼시 상의', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(704, 1151, 1, 'Magnacarta', '첼시 호박바지', 6, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(705, 1152, 1, 'Magnacarta', '첼시 장갑', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(706, 1153, 1, 'Magnacarta', '첼시 신발', 7, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(707, 1154, 1, 'Magnacarta', '첼시 스태프', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(708, 1155, 1, 'Fantasy', '성기사 상의(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(709, 1156, 1, 'Fantasy', '성기사 갑옷(남)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(710, 1157, 1, 'Fantasy', '성기사 장갑(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(711, 1158, 1, 'Fantasy', '성기사 신발(남)', 7, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(712, 1159, 1, 'Fantasy', '성기사 크로스소드', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(713, 1160, 1, 'Fantasy', '성기사 상의(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(714, 1161, 1, 'Fantasy', '성기사 가슴보호대(여)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(715, 1162, 1, 'Fantasy', '성기사 장갑(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(716, 1163, 1, 'Fantasy', '성기사 신발(여)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(717, 1164, 1, 'Fantasy', '성기사 쯔바이핸더', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(718, 1165, 1, 'Fantasy', '성기사 서고트(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(719, 1166, 1, 'Fantasy', '성기사 서고트A(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(720, 1167, 1, 'Fantasy', '성기사 서고트B(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(721, 1168, 1, 'Fantasy', '성기사 서고트C(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(722, 1169, 1, 'Fantasy', '성기사 서고트D(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(723, 1170, 1, 'Fantasy', '성기사 서고트E(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(724, 1171, 1, 'Fantasy', '성기사 서고트F(남)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(725, 1172, 1, 'Fantasy', '성기사 서고트(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(726, 1173, 1, 'Fantasy', '성기사 서고트A(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(727, 1174, 1, 'Fantasy', '성기사 서고트B(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(728, 1175, 1, 'Fantasy', '성기사 서고트C(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(729, 1176, 1, 'Fantasy', '성기사 서고트D(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(730, 1177, 1, 'Fantasy', '성기사 서고트E(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(731, 1178, 1, 'Fantasy', '성기사 서고트F(여)', 6, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(732, 1179, 1, 'Magnacarta', '칼린츠 가발', 3, 1, 23000, 11500, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(733, 1180, 1, 'Magnacarta', '페르난 가발', 3, 1, 19500, 9750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(734, 1181, 1, 'Magnacarta', '로프마 가발', 3, 1, 17300, 8650, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(735, 1182, 1, 'Magnacarta', '아도라 가발', 3, 2, 22000, 11000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(736, 1183, 1, 'Magnacarta', '쥬클레시아 가발', 3, 2, 21200, 10600, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(737, 1184, 1, 'Magnacarta', '첼시 가발', 3, 2, 18000, 9000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(738, 1185, 1, 'Magnacarta', '칼린츠 소울블레이드R', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(739, 1186, 1, 'G3P2', '리엔 차이나드레스A', 5, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(740, 1187, 1, 'Magnacarta', '카를로스 가발', 3, 1, 21850, 10925, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(741, 1188, 1, 'G3P2', '리엔 가발', 3, 2, 17500, 8750, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(742, 1189, 1, 'Magnacarta', '칼린츠 소울블레이드B', 8, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(743, 1190, 1, 'Apocalyse', '크리스티앙 가발', 3, 1, 16850, 8425, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(744, 1191, 1, 'Apocalyse', '죠안 가발', 3, 2, 19230, 9615, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(745, 1192, 1, 'Apocalyse', '크리스티앙 바지', 6, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(746, 1193, 1, 'Apocalyse', '크리스티앙 신발W', 7, 1, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(747, 1194, 1, 'Apocalyse', '죠안 빨간귀걸이', 9, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(748, 1195, 1, 'Apocalyse', '죠안 검R Type-II', 8, 2, 0, 0, 'DressShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(749, 1196, 1, 'Accessories', '나른한 푸우모자', 4, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(750, 1197, 1, 'Accessories', '만사태평 푸우모자', 4, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(751, 1198, 1, 'Accessories', '말똥말똥 푸우모자', 4, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(752, 1199, 1, 'Accessories', '못말리는 푸우모자', 4, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(753, 1200, 1, 'Accessories', '나른한 푸우모자', 4, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(754, 1201, 1, 'Accessories', '만사태평 푸우모자', 4, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(755, 1202, 1, 'Accessories', '말똥말똥 푸우모자', 4, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(756, 1203, 1, 'Accessories', '못말리는 푸우모자', 4, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(757, 1204, 1, 'Life', '털모자(남)', 4, 1, 320, 160, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(758, 1205, 1, 'Life', '털모자(여)', 4, 2, 320, 160, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(759, 1206, 1, 'Morden', '카우보이모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(760, 1207, 1, 'Weapone', '장창(남)', 8, 1, 1800, 900, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(761, 1208, 1, 'Weapone', '데쓰사이즈(여)', 8, 2, 1920, 960, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(762, 1209, 1, 'Weapone', '크로스보우(남)', 8, 1, 1750, 875, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(763, 1210, 1, 'Weapone', '크로스보우(여)', 8, 2, 1750, 875, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(764, 1211, 1, 'Accessories', '악마날개(남)', 9, 1, 3400, 1700, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(765, 1212, 1, 'Accessories', '악마날개(여)', 9, 2, 3400, 1700, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(766, 1213, 1, 'Fantasy', '하프엘프귀(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(767, 1214, 1, 'Fantasy', '하프엘프귀(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(768, 1215, 1, 'Fantasy', '하프엘프귀(나야)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(769, 1216, 1, 'Fantasy', '미노타의뿔(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(770, 1217, 1, 'Fantasy', '마녀의빗자루(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(771, 1218, 1, 'Student', '기초원소학(남)', 9, 1, 2800, 1400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(772, 1219, 1, 'Student', '기초원소학(여)', 9, 2, 2800, 1400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(773, 1220, 1, 'Accessories', '곰돌이귀마개(남)', 9, 1, 2200, 1100, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(774, 1221, 1, 'Accessories', '토끼귀마개(여)', 9, 2, 2200, 1100, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(775, 1222, 1, 'Accessories', '날개귀(남)', 9, 1, 2400, 1200, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(776, 1223, 1, 'Accessories', '날개귀(여)', 9, 2, 2400, 1200, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(777, 1224, 1, 'Accessories', '발키리날개귀(여)', 9, 2, 2750, 1375, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(778, 1225, 1, 'Accessories', '토끼귀(여)', 9, 2, 2750, 1375, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(779, 1226, 1, 'Accessories', '라운드이어링(여)', 9, 2, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(780, 1227, 1, 'Accessories', '주사위귀걸이(여)', 9, 2, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(781, 1228, 1, 'Life', '바이올린(남)', 9, 1, 1900, 950, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(782, 1229, 1, 'Life', '바이올린(여)', 9, 2, 1900, 950, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(783, 1230, 1, 'Life', '일렉트릭기타(남)', 9, 1, 2200, 1100, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(784, 1231, 1, 'Morden', '복주머니(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(785, 1232, 1, 'Morden', '복주머니(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(786, 1233, 1, 'Morden', '포도대장 돌격검(남)', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(787, 1234, 1, 'Morden', '부채(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(788, 1235, 1, 'Morden', '민속화관(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(789, 1236, 1, 'Accessories', '민속귀걸이(여)', 9, 2, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(790, 1237, 1, 'Morden', '빨간머플러(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(791, 1238, 1, 'Event', 'm4leaf토끼인형(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(792, 1239, 1, 'Event', 'm4leaf토끼인형(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(793, 1240, 1, 'Accessories', '루시안 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(794, 1241, 1, 'Accessories', '루시안 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(795, 1242, 1, 'Accessories', '막시민 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(796, 1243, 1, 'Accessories', '막시민 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(797, 1244, 1, 'Accessories', '조슈아 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(798, 1245, 1, 'Accessories', '조슈아 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(799, 1246, 1, 'Accessories', '보리스 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(800, 1247, 1, 'Accessories', '보리스 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(801, 1248, 1, 'Accessories', '란지에 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(802, 1249, 1, 'Accessories', '란지에 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(803, 1250, 1, 'Accessories', '시벨린 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(804, 1251, 1, 'Accessories', '시벨린 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(805, 1252, 1, 'Accessories', '이자크 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(806, 1253, 1, 'Accessories', '이자크 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(807, 1254, 1, 'Accessories', '이스핀 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(808, 1255, 1, 'Accessories', '이스핀 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(809, 1256, 1, 'Accessories', '티치엘 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(810, 1257, 1, 'Accessories', '티치엘 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(811, 1258, 1, 'Accessories', '클로에 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(812, 1259, 1, 'Accessories', '클로에 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(813, 1260, 1, 'Accessories', '아나벨 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(814, 1261, 1, 'Accessories', '아나벨 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(815, 1262, 1, 'Accessories', '나야 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(816, 1263, 1, 'Accessories', '나야 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(817, 1264, 1, 'Accessories', '밀라 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(818, 1265, 1, 'Accessories', '밀라 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(819, 1266, 1, 'Accessories', '벤야 인형(남)', 9, 1, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(820, 1267, 1, 'Accessories', '벤야 인형(여)', 9, 2, 4500, 2250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(821, 1268, 1, 'Accessories', '산타 인형(남)', 9, 1, 1000, 500, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(822, 1269, 1, 'Accessories', '산타 인형(여)', 9, 2, 1000, 500, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(823, 1270, 1, 'Accessories', '루돌프 인형(남)', 9, 1, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(824, 1271, 1, 'Accessories', '루돌프 인형(여)', 9, 2, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(825, 1272, 1, 'Accessories', '루시안 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(826, 1273, 1, 'Accessories', '루시안 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(827, 1274, 1, 'Accessories', '조슈아 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(828, 1275, 1, 'Accessories', '조슈아 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(829, 1276, 1, 'Accessories', '시벨린 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(830, 1277, 1, 'Accessories', '시벨린 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(831, 1278, 1, 'Accessories', '클로에 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(832, 1279, 1, 'Accessories', '클로에 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(833, 1280, 1, 'Accessories', '아나벨 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(834, 1281, 1, 'Accessories', '아나벨 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(835, 1282, 1, 'Accessories', '밀라 성탄인형(남)', 9, 1, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(836, 1283, 1, 'Accessories', '밀라 성탄인형(여)', 9, 2, 5200, 2600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(837, 1284, 1, 'Event', '성년축하 꽃송이(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(838, 1285, 1, 'Event', '성년축하 꽃송이(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(839, 1286, 1, 'Event', '석가탄신일 연등(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(840, 1287, 1, 'Event', '석가탄신일 연등(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(841, 1288, 1, 'Morden', '동자승 가발(남)', 3, 1, 8000, 4000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(842, 1289, 1, 'Morden', '동자승 가발(여)', 3, 2, 8000, 4000, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(843, 1290, 1, 'Sport', '축구유니폼 셔츠(남)', 5, 1, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(844, 1291, 1, 'Sport', '축구유니폼 바지(남)', 6, 1, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(845, 1292, 1, 'Sport', '축구유니폼 셔츠(남)', 5, 1, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(846, 1293, 1, 'Sport', '축구유니폼 바지(여)', 6, 2, 800, 400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(847, 1294, 1, 'Sport', '축구양말(남)', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(848, 1295, 1, 'Sport', '축구양말(여)', 9, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(849, 1296, 1, 'Sport', '축구화(남)', 7, 1, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(850, 1297, 1, 'Sport', '축구화(여)', 7, 2, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(851, 1298, 1, 'Sport', '축구공 포립노바(남)', 9, 1, 930, 465, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(852, 1299, 1, 'Sport', '축구공 포립노바(여)', 9, 2, 930, 465, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(853, 1300, 1, 'Sport', '응원용 태극기(남)', 9, 1, 300, 150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(854, 1301, 1, 'Sport', '응원용 태극기(여)', 9, 2, 300, 150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(855, 1302, 1, 'Event', '4LEAF 귀걸이 골드(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(856, 1303, 1, 'Event', '4LEAF 귀걸이 골드(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(857, 1304, 1, 'Event', '4LEAF 귀걸이 하늘(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(858, 1305, 1, 'Event', '4LEAF 귀걸이 하늘(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(859, 1306, 1, 'Event', '4LEAF 귀걸이 핑크(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(860, 1307, 1, 'Event', '4LEAF 귀걸이 핑크(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(861, 1308, 1, 'Life', '의사 모자', 4, 1, 300, 150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(862, 1309, 1, 'Life', '의사 상의', 5, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(863, 1310, 1, 'Life', '의사 하의', 6, 1, 400, 200, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(864, 1311, 1, 'Life', '의사 구두', 7, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(865, 1312, 1, 'Life', '의사 마스크', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(866, 1313, 1, 'Life', '의사 흰가운', 5, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(867, 1314, 1, 'Life', '의사 메스', 8, 1, 300, 150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(868, 1315, 1, 'Life', '간호사 모자', 4, 2, 300, 150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(869, 1316, 1, 'Life', '간호사 상의', 5, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(870, 1317, 1, 'Life', '간호사 치마', 6, 2, 400, 200, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(871, 1318, 1, 'Life', '간호사 스타킹', 6, 2, 350, 175, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(872, 1319, 1, 'Life', '간호사 가운', 5, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(873, 1320, 1, 'Life', '간호사 슬리퍼', 7, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(874, 1321, 1, 'Life', '간호사 진찰일지', 8, 2, 320, 160, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(875, 1322, 1, 'Life', '간호사 주사', 8, 2, 370, 185, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(876, 1323, 1, 'Life', '신부 상의', 5, 1, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(877, 1324, 1, 'Life', '신부 바지', 6, 1, 540, 270, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(878, 1325, 1, 'Life', '신부 제의', 5, 1, 620, 310, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(879, 1326, 1, 'Life', '신부 구두', 7, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(880, 1327, 1, 'Life', '신부 십자가', 8, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(881, 1328, 1, 'Life', '신부 성경책', 8, 1, 420, 210, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(882, 1329, 1, 'Life', '수녀 상의', 5, 2, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(883, 1330, 1, 'Life', '수녀 치마', 6, 2, 540, 270, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(884, 1331, 1, 'Life', '수녀 두건', 4, 2, 370, 185, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(885, 1332, 1, 'Life', '수녀 구두', 7, 2, 480, 240, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(886, 1333, 1, 'Life', '수녀 성경책', 8, 2, 420, 210, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(887, 1334, 1, 'Life', '수녀 묵주', 8, 2, 410, 205, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(888, 1335, 1, 'Life', '요리사 상의(남)', 5, 1, 580, 290, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(889, 1336, 1, 'Life', '요리사 바지(남)', 6, 1, 530, 265, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(890, 1337, 1, 'Life', '요리사 앞치마(남)', 6, 1, 520, 260, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(891, 1338, 1, 'Life', '요리사 구두(남)', 7, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(892, 1339, 1, 'Life', '요리사 모자(남)', 4, 1, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(893, 1340, 1, 'Life', '요리사 요리칼(남)L', 8, 1, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(894, 1341, 1, 'Life', '요리사 요리칼(남)S', 8, 1, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(895, 1342, 1, 'Life', '요리사 상의(여)', 5, 2, 580, 290, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(896, 1343, 1, 'Life', '요리사 바지(여)', 6, 2, 530, 265, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(897, 1344, 1, 'Life', '요리사 앞치마(여)', 6, 2, 520, 260, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(898, 1345, 1, 'Life', '요리사 구두(여)', 7, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(899, 1346, 1, 'Life', '요리사 모자(여)', 4, 2, 450, 225, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(900, 1347, 1, 'Life', '요리사 왕포크(여)', 8, 2, 600, 300, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(901, 1348, 1, 'Life', '요리사 프라이팬(여)', 8, 2, 620, 310, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(902, 1349, 1, 'Morden', '감모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(903, 1350, 1, 'Morden', '배모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(904, 1351, 1, 'Morden', '사과모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(905, 1352, 1, 'Morden', '밤모자(남)', 4, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(906, 1353, 1, 'Morden', '감모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(907, 1354, 1, 'Morden', '배모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(908, 1355, 1, 'Morden', '사과모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(909, 1356, 1, 'Morden', '밤모자(여)', 4, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(910, 1357, 1, 'Morden', '윷가락(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(911, 1358, 1, 'Morden', '윷가락(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(912, 1359, 1, 'Morden', '제가(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(913, 1360, 1, 'Morden', '제가(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(914, 1361, 1, 'Event', '특선목도리(빨강)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(915, 1362, 1, 'Event', '특선목도리(빨강)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(916, 1363, 1, 'Event', '특선목도리(주황)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(917, 1364, 1, 'Event', '특선목도리(주황)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(918, 1365, 1, 'Event', '특선목도리(노랑)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(919, 1366, 1, 'Event', '특선목도리(노랑)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(920, 1367, 1, 'Event', '특선목도리(초록)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(921, 1368, 1, 'Event', '특선목도리(초록)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(922, 1369, 1, 'Event', '특선목도리(파랑)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(923, 1370, 1, 'Event', '특선목도리(파랑)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(924, 1371, 1, 'Event', '특선목도리(남색)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(925, 1372, 1, 'Event', '특선목도리(남색)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(926, 1373, 1, 'Event', '특선목도리(보라)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(927, 1374, 1, 'Event', '특선목도리(보라)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(928, 1375, 1, 'Student', '화가의 대붓(남)', 9, 1, 650, 325, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(929, 1376, 1, 'Student', '화가의 대붓(여)', 9, 2, 650, 325, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(930, 1377, 1, 'Student', '화가의 소붓(남)', 9, 1, 520, 260, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(931, 1378, 1, 'Student', '화가의 소붓(여)', 9, 2, 520, 260, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(932, 1379, 1, 'Student', '화가의 물감(남)', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(933, 1380, 1, 'Student', '화가의 물감(여)', 9, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(934, 1381, 1, 'Student', '작가의 대펜(남)', 9, 1, 650, 325, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(935, 1382, 1, 'Student', '작가의 대펜(여)', 9, 2, 650, 325, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(936, 1383, 1, 'Student', '작가의 잉크(남)', 9, 1, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(937, 1384, 1, 'Student', '작가의 잉크(여)', 9, 2, 500, 250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(938, 1385, 1, 'Accessories', '월계관(남)', 4, 1, 950, 475, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(939, 1386, 1, 'Accessories', '월계관(여)', 4, 2, 950, 475, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(940, 1387, 1, 'Event', '4LEAF풍선(빨강)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(941, 1388, 1, 'Event', '4LEAF풍선(빨강)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(942, 1389, 1, 'Event', '4LEAF풍선(주황)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(943, 1390, 1, 'Event', '4LEAF풍선(주황)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(944, 1391, 1, 'Event', '4LEAF풍선(노랑)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(945, 1392, 1, 'Event', '4LEAF풍선(노랑)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(946, 1393, 1, 'Event', '4LEAF풍선(초록)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(947, 1394, 1, 'Event', '4LEAF풍선(초록)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(948, 1395, 1, 'Event', '4LEAF풍선(파랑)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(949, 1396, 1, 'Event', '4LEAF풍선(파랑)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(950, 1397, 1, 'Event', '4LEAF풍선(남색)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(951, 1398, 1, 'Event', '4LEAF풍선(남색)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(952, 1399, 1, 'Event', '4LEAF풍선(보라)', 8, 1, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(953, 1400, 1, 'Event', '4LEAF풍선(보라)', 8, 2, 3500, 1750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(954, 1401, 1, 'Morden', '장미꽃바구니(남)', 8, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(955, 1402, 1, 'Morden', '장미꽃바구니(여)', 8, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(956, 1403, 1, 'Accessories', '왕하트머리핀(남)', 9, 1, 7500, 3750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(957, 1404, 1, 'Accessories', '왕하트머리핀(여)', 9, 2, 7500, 3750, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(958, 1405, 1, 'Accessories', '작은하트머리핀(남)', 9, 1, 6800, 3400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(959, 1406, 1, 'Accessories', '작은하트머리핀(여)', 9, 2, 6800, 3400, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(960, 1407, 1, 'Accessories', '왕하트목걸이(남)', 9, 1, 6300, 3150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(961, 1408, 1, 'Accessories', '왕하트목걸이(여)', 9, 2, 6300, 3150, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(962, 1409, 1, 'Accessories', '작은하트목걸이(남)', 9, 1, 6500, 3250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(963, 1410, 1, 'Accessories', '작은하트목걸이(여)', 9, 2, 6500, 3250, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(964, 1411, 1, 'Accessories', '왕사랑리본(남)', 9, 1, 7200, 3600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(965, 1412, 1, 'Accessories', '왕사랑리본(여)', 9, 2, 7200, 3600, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(966, 1413, 1, 'Accessories', '사랑리본(남)', 9, 1, 6000, 3000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(967, 1414, 1, 'Accessories', '사랑리본(여)', 9, 2, 6000, 3000, 'AccessoryShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(968, 1415, 1, 'Event', '페스티발걸 상의(노랑)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(969, 1416, 1, 'Event', '페스티발걸 상의(주황)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(970, 1417, 1, 'Event', '페스티발걸 치마', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(971, 1418, 1, 'Event', '페스티발걸 장갑', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(972, 1419, 1, 'Event', '페스티발걸 부츠(노랑)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(973, 1420, 1, 'Event', '페스티발걸 부츠(주황)', 7, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(974, 1421, 1, 'Event', '페스티발걸 덧옷(노랑)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(975, 1422, 1, 'Event', '페스티발걸 덧옷(주황)', 6, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(976, 1423, 1, 'Event', '페스티발 티셔츠(노랑)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(977, 1424, 1, 'Event', '페스티발 티셔츠(노랑)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(978, 1425, 1, 'Event', '페스티발 티셔츠(검정)', 5, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(979, 1426, 1, 'Event', '페스티발 티셔츠(검정)', 5, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(980, 1427, 1, 'Event', '페스티발걸 가발', 3, 2, 33200, 16600, 'HairShop');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(981, 1428, 1, 'Event', '이벤트 핸드폰(남)', 9, 1, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(982, 1429, 1, 'Event', '이벤트 핸드폰(여)', 9, 2, 0, 0, 'DressShop2');
REPLACE INTO `tbl_ItemInfo` (`f_TID`, `f_Index`, `f_Type`, `f_Series`, `f_Name`, `f_Mount`, `f_Sex`, `f_BuyPrice`, `f_SellPrice`, `f_Store`) VALUES
	(983, 1430, 1, 'Event', '이벤트 핸드폰(나야)', 9, 2, 0, 0, 'DressShop2');
/*!40000 ALTER TABLE `tbl_ItemInfo` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
